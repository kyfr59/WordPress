(jQuery)(function($) {

    // PRETTYPHOTO LIGHTBOX
    if (jQuery().prettyPhoto) {
        piPrettyphoto();
    }
    function piPrettyphoto() {
        $(".pi-portfolio-carousel a[data-gal^='prettyPhoto']").prettyPhoto({social_tools: false});
    }

    //PORTFOLIO CAROUSEL
    //	Responsive layout, resizing the items
    $('.pi-portfolio-carousel').each(function() {
        var auto = $(this).data('play') == '1';
        var timeoutDuration = $(this).data('timeout');

        $(this).carouFredSel({
            responsive: true,
            width: '100%',
            height: '100%',
            auto: {
                play: auto,
                timeoutDuration: timeoutDuration
            },
            scroll: 1,
            prev: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav").find(".c_prev");
                }
            },
            next: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav").find(".c_next");
                }
            },
            items: {
                width: 400,
                height: '100%',
                visible: {
                    min: 1,
                    max: 4
                }
            }

        });
    });

});
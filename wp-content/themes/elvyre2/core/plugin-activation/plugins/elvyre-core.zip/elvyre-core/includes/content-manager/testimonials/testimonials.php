<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Testimonials")) {

    class CMA_Shortcodes_Testimonials extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Testimonials', 'pi_framework');
            $settings['description'] = __('Simple UI component.', 'pi_framework');
            $settings['shortcode'] = 'cma_testimonials';
            $settings['nested'] = array('cma_testimonials_item');

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* scripts */
            wp_enqueue_script('cma-scripts-testimonials', plugin_dir_url(__FILE__) . 'js/testimonials.js', array('jquery', 'caroufredsel'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $i = 1;
            $testimonials_html = '';

            extract(shortcode_atts(array(
                'type' => '',
                'testimonials' => '',
                'auto_scroll' => '0',
                'timeout' => '3000',
                'navigation' => '0'
                            ), $atts, 'cma_testimonials'));

            foreach ($testimonials as $index => $testimonial) {

                $count = count($testimonials);

                // execute any shortcode that might be in text
                $content = do_shortcode($testimonial['text']);

                // container type depends on testimonials type
                $testimonial_container = ($count > 1) ? 'li' : 'article';

                // get image if available
                $images = $testimonial['image'];
                if (!empty($images)) {
                    // array of images
                    $image = explode(',', $images);

                    //get first image
                    $image_url = wp_get_attachment_image_src($image[0], 'full');

                    // crop image
                    $params = array('width' => 100, 'height' => 100);
                    if ($is_retina) {
                        $params = array('width' => 200, 'height' => 200);
                    }
                    $author_image = bfi_thumb($image_url[0], $params);
                    $author_image = "<div class='testimonial-image-container'><img src='{$author_image}' alt='{$testimonial['author']}'></div>";
                }

                // one testimonial
                $testimonials_html .= "<{$testimonial_container} class='testimonial {$type}'>
                                    <div class='testimonial-text'>
                                        <p>{$content}</p>";

                if ($type == 'style-2') {
                    $testimonials_html .= "<span class='author'>{$testimonial['author']},{$testimonial['position']}</span></div>";
                } else {
                    $testimonials_html .= "</div><div class='testimonial-author clearfix'>
                                        {$author_image}

                                        <h6 class='testimonial-author-name'>{$testimonial['author']},</h6>
                                        <span class='testimonial-author-company'>{$testimonial['position']}</span>
                                    </div>";
                }

                $testimonials_html .= "</{$testimonial_container}>";

                $i++;
            }

            // wrap content if carousel is in use
            if ($count > 1) {
                $html = "<ul class='testimonial-carousel carousel-li' data-play='{$auto_scroll}' data-timeout='{$timeout}'>{$testimonials_html}</ul>";
                if ($navigation == '1') {
                    $html .= "<div class='clearfix'></div>
                        <ul class='carousel-nav'>
                            <li>
                                <a class='c_prev' href='#'></a> 
                            </li>
                            <li>
                                <a class='c_next' href='#'></a>
                            </li>
                        </ul>";
                }
            } else {
                $html = $testimonials_html;
            }


            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select testimonials type.', 'pi_framework'),
                    'options' => array(
                        'style-1' => __('Text + Image', 'pi_framework'),
                        'style-2' => __('Text only', 'pi_framework')
                    ),
                    'default' => ''
                ),
                'auto_scroll' => array(
                    'type' => 'checkbox',
                    'title' => __('Auto Scroll', 'pi_framework'),
                    'description' => __('Set testimonial to auto scroll.', 'pi_framework'),
                    'default' => '0'
                ),
                'timeout' => array(
                    'type' => 'number',
                    'title' => __('Scroll Timeout', 'pi_framework'),
                    'description' => __('Enter scrolling timeout.', 'pi_framework'),
                    'default' => '3000',
                    'options' => array(
                        'step' => 10
                    )
                ),
                'navigation' => array(
                    'type' => 'checkbox',
                    'title' => __('Navigation', 'pi_framework'),
                    'description' => __('Show navigation.', 'pi_framework'),
                    'default' => '0'
                ),
                'testimonials' => array(
                    'type' => 'group',
                    'title' => __('Testimonials', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'text' => array(
                            'type' => 'textarea',
                            'title' => __('Text', 'pi_framework'),
                            'description' => __('Testimonial text.', 'pi_framework')
                        ),
                        'author' => array(
                            'type' => 'text',
                            'title' => __('Author', 'pi_framework'),
                            'description' => __('Testimonial author name.', 'pi_framework')
                        ),
                        'position' => array(
                            'type' => 'text',
                            'title' => __('Position', 'pi_framework'),
                            'description' => __('Testimonial author position.', 'pi_framework')
                        ),
                        'image' => array(
                            'type' => 'image',
                            'title' => __('Image', 'pi_framework'),
                            'description' => __('Testimonial author image.', 'pi_framework'),
                            'condition' => array('type', '==', 'style-1')
                        ),
                    )
                )
            );
        }

    }

}
?>

<?php

/* * ***********************************************
 * Theme Post Types
 * 
 * Functions for registering custom post types 
 * and adding columns to list of posts
 * ********************************************** */

/* ------------------------------------------------------------------
 * Portfolio post type
  ------------------------------------------------------------------- */

function pi_create_postype_portfolio() {
    $labels = array(
        'name' => __('Portfolio', 'pi_framework'),
        'singular_name' => __('Portfolio', 'pi_framework'),
        'add_new' => _x('Add New', 'portfolio', 'pi_framework'),
        'add_new_item' => __('Add New Item', 'pi_framework'),
        'edit_item' => __('Edit Item', 'pi_framework'),
        'new_item' => __('New Item', 'pi_framework'),
        'view_item' => __('View Item', 'pi_framework'),
        'search_items' => __('Search Item', 'pi_framework'),
        'not_found' => __('No Portoflio images found', 'pi_framework'),
        'not_found_in_trash' => __('No portfolio images found in Trash', 'pi_framework'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => array('slug' => 'portfolio-item', 'with_front' => true),
        'show_ui' => true,
        'query_var' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => '20',
        'menu_icon' => ELV_PLUGIN_URL . '/img/cpt/portfolio.png',
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'excerpt')
    );

    register_post_type('pi_portfolio', $args);
}

add_action('init', 'pi_create_postype_portfolio');

/* Create taxonomy Portfolio Category */

function pi_create_portfolio_taxonomies() {
    register_taxonomy("portfolio-category", array("pi_portfolio"), array("hierarchical" => true, "label" => __("Portfolio Categories", 'pi_framework'), "singular_label" => __("Portfolio Category", 'pi_framework'), "rewrite" => array('slug' => 'portfolio-category', 'hierarchical' => true)));
    if (!term_exists('default', 'portfolio-category')) {
        $parent_term = term_exists('default', 'portfolio-category'); // array is returned if taxonomy is given
        $parent_term_id = $parent_term['term_id']; // get numeric term id
        wp_insert_term(
                __('Default', 'pi_framework'), // the term 
                'portfolio-category', // the taxonomy
                array(
            'description' => __('Default portfolio category.', 'pi_framework'),
            'slug' => 'default',
            'parent' => $parent_term_id
                )
        );
    }
}

add_action('init', 'pi_create_portfolio_taxonomies');

/* Set default portfolio category when publishing portfolio post */

function pi_set_default_object_terms($post_id, $post) {
    if ($post->post_status === 'publish' && $post->post_type == "pi_portfolio") {
        $defaults = array(
            'portfolio-category' => array('default')
        );
        $taxonomies = get_object_taxonomies($post->post_type);
        foreach ((array) $taxonomies as $taxonomy) {
            $terms = wp_get_post_terms($post_id, $taxonomy);
            if (empty($terms) && array_key_exists($taxonomy, $defaults)) {
                wp_set_object_terms($post_id, $defaults[$taxonomy], $taxonomy);
            }
        }
    }
}

add_action('save_post', 'pi_set_default_object_terms', 100, 2);

/* Show Portfolio image in list of Portfolios */

// Create new column
function pi_columns_head_only_pi_portfolio($defaults) {
    $defaults['portfolio_image'] = 'Image';
    return $defaults;
}

// show image in column
function pi_columns_content_only_pi_portfolio($column_name, $post_ID) {
    if ($column_name == 'portfolio_image') {
        $images = get_post_custom_values('pf_image', $post_ID);
        $image_url = wp_get_attachment_image_src($images[0], 'full');
        $params = array("width" => 150, "height" => 120);
        $featured_image = bfi_thumb($image_url[0], $params);

        if ($featured_image) {
            // image found
            echo '<img src="' . $featured_image . '" alt="Image"/>';
        } else {
            // no image
            $default_image = ELV_PLUGIN_URL . "/js/holder.js/150x100/auto/text:Image";
            echo "<img data-src='{$default_image}' width='150'/>";
        }
    }
}

// Portfolio post type filter
add_filter('manage_pi_portfolio_posts_columns', 'pi_columns_head_only_pi_portfolio', 10);
add_action('manage_pi_portfolio_posts_custom_column', 'pi_columns_content_only_pi_portfolio', 10, 2);

?>

<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Social_Icons")) {

    class CMA_Shortcodes_Social_Icons extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Social Icons', 'pi_framework');
            $settings['description'] = __('List with social icons.', 'pi_framework');
            $settings['shortcode'] = 'cma_social_icons';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            $color_style = '';

            extract(shortcode_atts(array(
                'custom_color' => '',
                'networks' => ''
                            ), $atts, 'cma_social_icons'));

            if (!empty($custom_color)) {
                $color_style = "style='color: {$custom_color}'";
            }

            $html = "<ul class='team-social-links'>";

            foreach ($networks as $index => $network) {
                $network['link'] = esc_url($network['link']);

                $html .= "<li><a href='{$network['link']}' class='{$network['icon']}' {$color_style}></a></li>";
            }

            $html .= "</ul>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'custom_color' => array(
                    'type' => 'color_picker',
                    'title' => __('Custom color', 'pi_framework'),
                    'description' => __('Choose custom icon color. Default color is grey.', 'pi_framework')
                ),
                'networks' => array(
                    'type' => 'group',
                    'title' => __('Items', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Select social network.', 'pi_framework'),
                            'options' => pi_get_pixons_names()
                        ),
                        'link' => array(
                            'type' => 'text',
                            'title' => __('Link', 'pi_framework'),
                            'description' => __('URL to social network profile.', 'pi_framework'),
                            'default' => 'http://'
                        )
                    )
                )
            );
        }

    }

}
?>

(jQuery)(function($) {
    /* ================ SERVICES CAROUSEL ================ */
    $('.services-carousel').each(function() {
        var auto = $(this).data('play') == '1';
        var timeoutDuration = $(this).data('timeout');


        $(this).carouFredSel({
            responsive: true,
            width: '100%',
            auto: {
                play: auto,
                timeoutDuration: timeoutDuration
            },
            scroll: 1,
            prev: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav").find(".c_prev");
                }
            },
            next: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav").find(".c_next");
                }
            },
            swipe: {
                onMouse: true,
                onTouch: true
            },
            items: {
                width: 370,
                height: 'auto',
                visible: {
                    min: 1,
                    max: 3
                }
            }
        });
    });



});
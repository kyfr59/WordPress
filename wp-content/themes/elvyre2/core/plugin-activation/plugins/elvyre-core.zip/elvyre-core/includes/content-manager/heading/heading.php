<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Heading")) {

    class CMA_Shortcodes_Heading extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Heading', 'pi_framework');
            $settings['description'] = __('Two types of section titles.', 'pi_framework');
            $settings['shortcode'] = 'cma_heading';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'type' => 'classic',
                'title' => 'Heading text',
                'subtitle' => ''
                            ), $atts, 'cma_heading'));

            if ($type == 'classic') {
                $html = "<section class='heading-bordered'>
                    <h3>{$title}</h3>
                </section>";
            } else {
                $html = "<section class='heading-centered'><h2>{$title}</h2>";
                if (!empty($subtitle))
                    $html .= "<p>{$subtitle}</p></section>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select heading type.', 'pi_framework'),
                    'options' => array(
                        'classic' => __('Classic', 'pi_framework'),
                        'centered' => __('Centered', 'pi_framework')
                    ),
                    'default' => 'classic'
                ),
                'title' => array(
                    'type' => 'text',
                    'title' => __('Title', 'pi_framework'),
                    'description' => __('Enter heading title.', 'pi_framework'),
                    'placeholder' => 'Title'
                ),
                'subtitle' => array(
                    'type' => 'text',
                    'title' => __('Subtitle', 'pi_framework'),
                    'description' => __('Enter heading subtitle.', 'pi_framework'),
                    'placeholder' => 'Subtitle',
                    'condition' => array('type', '==', 'centered')
                )
            );
        }

    }

}
?>

<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Note")) {

    class CMA_Shortcodes_Note extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Note', 'pi_framework');
            $settings['description'] = __('Section where you can introduce yourself.', 'pi_framework');
            $settings['shortcode'] = 'cma_note';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            $target_html = '';
            $bkg_style = '';

            extract(shortcode_atts(array(
                'type' => '',
                'background' => '',
                'text_size' => 'h2',
                'text' => 'Note text goes here.',
                'button' => '',
                'button_text' => 'Button',
                'button_url' => '',
                'target' => '',
                'btn_type' => 'medium',
                'btn_size' => '',
                'btn_icon' => '',
                'btn_color' => '',
                'btn_custom_color' => ''
                            ), $atts, 'cma_note'));

            $button_url = esc_url($button_url);            

            if ($target == '1') {
                $target_html = 'target="_BLANK"';
            }

            if (!empty($background) && ($type == 'has-background')) {
                $bkg_style = "style='background: {$background}'";
            }

            if (!empty($btn_icon)) {
                $btn_icon = "<i class='{$btn_icon}'></i>";
            }

            if (!empty($btn_custom_color)) {
                $btn_color = "";
                $btn_custom_color = "style='background-color: {$btn_custom_color}'";
            }

            $button_html = ($button == '1') ? "<a class='btn-{$btn_size} {$btn_type} {$btn_color}' href='{$button_url}' {$btn_custom_color} {$target_html}>{$btn_icon} {$button_text}</a>" : '';
            $html = "<section class='note {$type}' {$bkg_style}><{$text_size}>{$text}</{$text_size}>{$button_html}</section>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select note type.', 'pi_framework'),
                    'options' => array(
                        'simple' => __('Simple', 'pi_framework'),
                        'has-background' => __('Background', 'pi_framework')
                    ),
                    'default' => ''
                ),
                'background' => array(
                    'type' => 'color_picker',
                    'title' => __('Background color', 'pi_framework'),
                    'description' => __('Select background color. Default is grey.', 'pi_framework'),
                    'condition' => array('type', '==', 'has-background')
                ),
                'text_size' => array(
                    'type' => 'select',
                    'title' => __('Text size', 'pi_framework'),
                    'description' => __('Select text size.', 'pi_framework'),
                    'options' => array(
                        'h1' => 'H1',
                        'h2' => 'H2',
                        'h3' => 'H3',
                        'h4' => 'H4',
                        'h5' => 'H5',
                        'h6' => 'H6'
                    ),
                    'default' => 'h2'
                ),
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Note text.', 'pi_framework')
                ),
                'button' => array(
                    'type' => 'checkbox',
                    'title' => __('Show button', 'pi_framework'),
                    'description' => __('Check to show button.', 'pi_framework'),
                    'default' => '1'
                ),
                'btn_type' => array(
                    'type' => 'radio',
                    'title' => __('Button Type', 'pi_framework'),
                    'description' => __('Select button type.', 'pi_framework'),
                    'options' => array(
                        'empty' => __('Empty', 'pi_framework'),
                        'filled' => __('Filled', 'pi_framework')
                    ),
                    'default' => 'empty',
                    'condition' => array('button', '==', '1')
                ),
                'btn_size' => array(
                    'type' => 'radio',
                    'title' => __('Button Size', 'pi_framework'),
                    'description' => __('Select button size.', 'pi_framework'),
                    'options' => array(
                        'medium' => __('Medium', 'pi_framework'),
                        'big' => __('Big', 'pi_framework')
                    ),
                    'default' => 'medium',
                    'condition' => array('button', '==', '1')
                ),
                'btn_icon' => array(
                    'type' => 'icon_picker',
                    'title' => __('Button Icon', 'pi_framework'),
                    'description' => __('Add button icon.', 'pi_framework'),
                    'condition' => array('button', '==', '1'),
                    'options' => pi_icons_font_names()
                ),
                'btn_color' => array(
                    'type' => 'select',
                    'title' => __('Button Color', 'pi_framework'),
                    'description' => __('Predefined button color.', 'pi_framework'),
                    'options' => array(
                        '' => 'Default',
                        'black' => 'Black',
                        'white' => 'White',
                        'grey' => 'Grey',
                        'silver' => 'Silver',
                        'blue' => 'Blue',
                        'red' => 'Red',
                        'yellow' => 'Yellow',
                        'orange' => 'Orange',
                        'green' => 'Green',
                        'aqua' => 'Aqua'
                    ),
                    'default' => 'black',
                    'condition' => array('button', '==', '1')
                ),
                'btn_custom_color' => array(
                    'type' => 'color_picker',
                    'title' => __('Button Custom Color', 'pi_framework'),
                    'description' => __('Select button custom color.', 'pi_framework'),
                    'condition' => array('button', '==', '1')
                ),
                'button_text' => array(
                    'type' => 'text',
                    'title' => __('Button Text', 'pi_framework'),
                    'description' => __('Enter button text.', 'pi_framework'),
                    'placeholder' => 'Button',
                    'condition' => array('button', '==', '1')
                ),
                'button_url' => array(
                    'type' => 'text',
                    'title' => __('Button URL', 'pi_framework'),
                    'description' => __('Enter button URL.', 'pi_framework'),
                    'placeholder' => 'http://',
                    'condition' => array('button', '==', '1')
                ),
                'target' => array(
                    'type' => 'checkbox',
                    'title' => __('Button target', 'pi_framework'),
                    'description' => __('Open link in new window/tab', 'pi_framework'),
                    'default' => '0',
                    'condition' => array('button', '==', '1')
                ),
            );
        }

    }

}
?>

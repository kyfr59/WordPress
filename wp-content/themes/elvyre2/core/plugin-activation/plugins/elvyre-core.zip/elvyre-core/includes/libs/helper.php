<?php

/* * ***************************
 * Theme helper functions
 * 
 * *************************** */

/* -----------------------------------------
 * Substring text
  ----------------------------------------- */
if (!function_exists('_substr')) {

    function _substr($str, $length, $minword = 3) {
        $sub = '';
        $len = 0;

        foreach (explode(' ', $str) as $word) {
            $part = (($sub != '') ? ' ' : '') . $word;
            $sub .= $part;
            $len += strlen($part);

            if (strlen($word) > $minword && strlen($sub) >= $length) {
                break;
            }
        }

        return $sub . (($len < strlen($str)) ? '...' : '');
    }

}
/* --------------------------------------------
 * Verify if visitor is using Internet Explorer
  --------------------------------------------- */
if (!function_exists('pi_detect_ie')) {

    function pi_detect_ie() {
        $browsers = array();
        $ie6 = strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.0');
        $ie7 = strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 7.0');
        $ie8 = strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 8.0');
        if ($ie6 !== false) {
            $browsers['ie6'] = 'true';
        } else if ($ie7 !== false) {
            $browsers['ie7'] = 'true';
        } else if ($ie8 !== false) {
            $browsers['ie8'] = 'true';
        }

        return $browsers;
    }

}
/* ------------------------------------------------------------------
 * Check the current post for the existence of a short code
  ------------------------------------------------------------------ */
if (!function_exists('pi_has_shortcode')) {

    function pi_has_shortcode($shortcode = '') {

        $post_to_check = get_post(get_the_ID());

        // false because we have to search through the post content first
        $found = false;

        // if no short code was provided, return false
        if (!$shortcode) {
            return $found;
        }
        // check the post content for the short code
        if (stripos($post_to_check->post_content, '[' . $shortcode) !== false) {
            // we have found the short code
            $found = true;
        }

        // return our final results
        return $found;
    }

}
/* --------------------------------------------
 * Adjust brightness by changing Hex value
  --------------------------------------------- */
if (!function_exists('pi_adjust_color_brightness')) {

    function pi_adjust_color_brightness($hex, $steps) {
        // Steps should be between -255 and 255. Negative = darker, positive = lighter
        $steps = max(-255, min(255, $steps));

        // Format the hex color string
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
        }

        // Get decimal values
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));

        // Adjust number of steps and keep it inside 0 to 255
        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));

        $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
        $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
        $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);

        return '#' . $r_hex . $g_hex . $b_hex;
    }

}


?>

<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Blockquote")) {

    class CMA_Shortcodes_Blockquote extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Blockquote', 'pi_framework');
            $settings['description'] = __('Section with text that is quoted from another source.', 'pi_framework');
            $settings['shortcode'] = 'cma_blockquote';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'text' => 'classic',
                'author' => ''
                            ), $atts, 'cma_blockquote'));

            $html = "<blockquote><p>{$text}</p><cite>{$author}</cite></blockquote>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Enter blockquote text here.', 'pi_framework')
                ),
                'author' => array(
                    'type' => 'text',
                    'title' => __('Author', 'pi_framework'),
                    'description' => __('Enter blockquote author.', 'pi_framework')
                )
            );
        }

    }

}
?>

(jQuery)(function($){
    /* ================ INFORMATION BOXES ================ */
        $('.information-boxes .close').on('click', function() {
            $(this).parent().slideUp(300);
        });
    
});
<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Services_2")) {

    class CMA_Shortcodes_Services_2 extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Services - Classic/Box', 'pi_framework');
            $settings['description'] = __('Two styles of services: Classic & Box.', 'pi_framework');
            $settings['shortcode'] = 'cma_services_2';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            $html = '';

            extract(shortcode_atts(array(
                'type' => 'classic',
                'text' => 'Service',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean est eros, viverra at dolor nec, laoreet rhoncus felis. Maecenas hendrerit posuere luctus. Proin sed enim nulla.',
                'icon' => 'icon-leaf',
                'link' => '',
                'custom_link' => '',
                'readmore' => __('Read more...', 'pi_framework'),
                'link_area' => '0'
                            ), $atts, 'cma_services_2'));

            // get service link
            if (!empty($custom_link)) {
                $link = esc_url($custom_link);                
            } else if (!empty($link) && $link != '-1') {
                $link = get_permalink($link);
            } else {
                $link = false;
            }

            // two services styles
            if ($type == 'box') {
                if ($link_area == '1' && !empty($link))
                    $html .= "<a href='{$link}'>";

                $html .= "<section class='service-box-2'>
                        <div class='icon'>
                            <i class='{$icon}'></i>
                        </div>

                        <h5>{$text}</h5>

                        <p>{$description}</p>";

                if (!empty($link) && $link_area == '0') {
                    $html .= "<a href='{$link}' class='read-more'>{$readmore}</a>";
                }else{
                    $html .= "<span class='read-more'>{$readmore}</span>";
                }

                if ($link_area == '1' && !empty($link))
                    $html .= "</a>";

                $html .= "</section>";
            } else {
                if ($link_area == '1' && !empty($link))
                    $html .= "<a href='{$link}'>";
                    
                $html .= "<section class = 'service-box-1'>
                            <div class = 'icon {$icon}'></div>";

                if (!empty($link) && $link_area == '0') {
                    $html .= "<a href = '{$link}'>
                                <h5>{$text}</h5>
                                </a>";
                } else {
                    $html .= "<h5>{$text}</h5>";
                }

                $html .= "<p>{$description}</p>
                        </section>";
                
                if ($link_area == '1' && !empty($link))
                        $html .= "</a>";
            }


            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select services type.', 'pi_framework'),
                    'options' => array(
                        'classic' => __('Classic', 'pi_framework'),
                        'box' => __('Box', 'pi_framework'),
                    ),
                    'default' => 'classic'
                ),
                'text' => array(
                    'type' => 'text',
                    'title' => __('Title', 'pi_framework'),
                    'description' => __('Service title.', 'pi_framework')
                ),
                'description' => array(
                    'type' => 'textarea',
                    'title' => __('Description', 'pi_framework'),
                    'description' => __('Service description.', 'pi_framework')
                ),
                'icon' => array(
                    'type' => 'icon_picker',
                    'title' => __('Icon', 'pi_framework'),
                    'description' => __('Add service icon.', 'pi_framework'),
                    'options' => pi_icons_font_names()
                ),
                'link' => array(
                    'type' => 'select',
                    'title' => __('Link', 'pi_framework'),
                    'description' => __('Link to page from this service.', 'pi_framework'),
                    'data' => 'pages',
                    'default' => ''
                ),
                'custom_link' => array(
                    'type' => 'text',
                    'title' => __('Custom URL', 'pi_framework'),
                    'description' => __('Enter custom URL for this service.', 'pi_framework')
                ),
                'readmore' => array(
                    'type' => 'text',
                    'title' => __('Read More', 'pi_framework'),
                    'description' => __('Read More button text (only for box type).', 'pi_framework'),
                    'default' => 'Read more...',
                    'condition' => array('type', '==', 'box')
                ),
                'link_area' => array(
                    'type' => 'checkbox',
                    'title' => __('Link Area', 'pi_framework'),
                    'description' => __('Enable if you want to use whole service area as link.', 'pi_framework'),
                    'default' => '0'
                ),
            );
        }

    }

}
?>

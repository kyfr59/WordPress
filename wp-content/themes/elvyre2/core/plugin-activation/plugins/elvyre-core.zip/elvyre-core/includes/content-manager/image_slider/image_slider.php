<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Image_Slider")) {

    class CMA_Shortcodes_Image_Slider extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Image Slider', 'pi_framework');
            $settings['description'] = __('Simple image slider.', 'pi_framework');
            $settings['shortcode'] = 'cma_image_slider';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-image-slider', plugin_dir_url(__FILE__) . 'js/image_slider.js', array('jquery', 'nivoslider'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            $html_images = '';
            $nav_html = '';

            extract(shortcode_atts(array(
                'images' => '',
                'navigation' => '1',
                'manual_advance' => '1',
                'pause_hover' => '1',
                'pause' => '3000'
                            ), $atts, 'cma_image_slider'));

            // team member image
            $images = explode(',', $images);

            foreach ($images as $index => $image) {
                //get first image
                $image_url = wp_get_attachment_image_src($image, 'full');

                if (empty($image_url))
                    continue;

                $html_images .= "<img src='{$image_url[0]}' alt='slider image'/>";
            }

            $html = "<section class='nivoSlider' data-manual='{$manual_advance}' data-pause='{$pause}' data-navigation='{$navigation}' data-pause-hover='{$pause_hover}'>{$html_images}</section>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'images' => array(
                    'type' => 'image',
                    'title' => __('Images', 'pi_framework'),
                    'description' => __('Upload slider images.', 'pi_framework')
                ),
                'navigation' => array(
                    'type' => 'checkbox',
                    'title' => __('Show navigation', 'pi_framework'),
                    'description' => __('Check this to show navigation.', 'pi_framework'),
                    'default' => '1'
                ),
                'manual_advance' => array(
                    'type' => 'checkbox',
                    'title' => __('Force manual transitions', 'pi_framework'),
                    'description' => __('Disable automatic sliding.', 'pi_framework'),
                    'default' => '1'
                ),
                'pause_hover' => array(
                    'type' => 'checkbox',
                    'title' => __('Hover pause', 'pi_framework'),
                    'description' => __('Pause sliding on hover.', 'pi_framework'),
                    'default' => '1'
                ),
                'pause' => array(
                    'type' => 'number',
                    'title' => __('Slide Pause', 'pi_framework'),
                    'description' => __('Enter sliding timeout.', 'pi_framework'),
                    'default' => '3000',
                    'options' => array(
                        'step' => 10
                    )
                )
            );
        }

    }

}
?>

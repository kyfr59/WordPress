<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Buttons")) {

    class CMA_Shortcodes_Buttons extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Buttons', 'pi_framework');
            $settings['description'] = __('Buttons of multiple types, sizes and colors.', 'pi_framework');
            $settings['shortcode'] = 'cma_buttons';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'type' => 'empty',
                'size' => 'medium',
                'icon' => '',
                'color' => '',
                'text' => 'Button',
                'link' => '',
                'target' => '',
                            ), $atts, 'cma_buttons'));

            $link = esc_url($link);

            if (!empty($icon)) {
                $icon = "<i class='{$icon}'></i>";
            }

            if ($target == '1') {
                $target = 'target="_BLANK"';
            }

            $html = "<a href='{$link}' class='btn-{$size} {$type} {$color}' {$target}>{$icon} {$text}</a>";



            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select button type', 'pi_framework'),
                    'options' => array(
                        'empty' => __('Empty', 'pi_framework'),
                        'filled' => __('Filled', 'pi_framework')
                    ),
                    'default' => 'empty'
                ),
                'size' => array(
                    'type' => 'radio',
                    'title' => __('Size', 'pi_framework'),
                    'description' => __('Select button size.', 'pi_framework'),
                    'options' => array(
                        'medium' => __('Medium', 'pi_framework'),
                        'big' => __('Big', 'pi_framework')
                    ),
                    'default' => 'medium'
                ),
                'icon' => array(
                    'type' => 'icon_picker',
                    'title' => __('Icon', 'pi_framework'),
                    'description' => __('Add button icon.', 'pi_framework'),
                    'options' => pi_icons_font_names()
                ),
                'color' => array(
                    'type' => 'select',
                    'title' => __('Color', 'pi_framework'),
                    'description' => __('Predefined button color.', 'pi_framework'),
                    'options' => array(
                        '' => 'Default',
                        'black' => 'Black',
                        'grey' => 'Grey',
                        'silver' => 'Silver',
                        'blue' => 'Blue',
                        'red' => 'Red',
                        'yellow' => 'Yellow',
                        'orange' => 'Orange',
                        'green' => 'Green',
                        'aqua' => 'Aqua'
                    ),
                    'default' => 'black'
                ),
                'text' => array(
                    'type' => 'text',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Button text.', 'pi_framework'),
                    'placeholder' => 'Button'
                ),
                'link' => array(
                    'type' => 'text',
                    'title' => __('Link', 'pi_framework'),
                    'description' => __('Button link.', 'pi_framework'),
                    'placeholder' => 'www.google.com'
                ),
                'target' => array(
                    'type' => 'checkbox',
                    'title' => __('Target', 'pi_framework'),
                    'description' => __('Open URL in new window.', 'pi_framework')
                ),
            );
        }

    }

}
?>

<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Image_Carousel")) {

    class CMA_Shortcodes_Image_Carousel extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Image Carousel', 'pi_framework');
            $settings['description'] = __('Simple image carousel.', 'pi_framework');
            $settings['shortcode'] = 'cma_image_carousel';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-image-carousel', plugin_dir_url(__FILE__) . 'js/image_carousel.js', array('jquery', 'caroufredsel'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $html_images = '';
            $nav_html = '';

            extract(shortcode_atts(array(
                'type' => 'basic',
                'images' => '',
                'navigation' => '1',
                'auto_scroll' => '0',
                'timeout' => '3000',
                'image_link' => '',
                'target' => '0'
                            ), $atts, 'cma_image_carousel'));

            // carosel images
            if ($type == 'basic') {
                $images = explode(',', $images);
            } else if ($type == 'link' && !empty($image_link)) {
                $images = wp_list_pluck($image_link, 'image');
            }

            foreach ($images as $index => $image) {
                $image = trim($image, ',');

                //get first image
                $image_url = wp_get_attachment_image_src($image, 'full');

                if (empty($image_url))
                    continue;

                // crop the image
                $params = array('width' => 165);
                if ($is_retina) {
                    $params = array('width' => 330);
                }
                $cropped_image = bfi_thumb($image_url[0], $params);

                if ($type == 'basic') {
                    $html_images .= "<li><img src='{$cropped_image}' alt='image'/></li>";
                } else if ($type == 'link') {
                    $link = $image_link[$index]['url'];

                    $link = esc_url($link);                     

                    if ($target == '1') {
                        $target = 'target="_BLANK"';
                    }else{
                        $target = '';
                    }

                    $html_images .= "<li><a href='{$link}' {$target}><img src='{$cropped_image}' alt='image'/></a></li>";
                }
            }

            if ($navigation == '1')
                $nav_html = "<div class='carousel-nav-container'>
                                <ul class='carousel-nav'>
                                    <li>
                                        <a class='c_prev' href='#'></a> 
                                    </li>
                                    <li>
                                        <a class='c_next' href='#'></a>
                                    </li>
                                </ul>
                            </div>";

            $html = "<div class='image-carousel'><ul class='carousel-li client-carousel' data-play='{$auto_scroll}' data-timeout='{$timeout}'>{$html_images}</ul>";
            $html .= $nav_html . "</div>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Carousel type', 'pi_framework'),
                    'description' => __('Choose between two types of carousel.', 'pi_framework'),
                    'options' => array(
                        'basic' => 'Basic',
                        'link' => 'Image as link'
                    ),
                    'default' => 'basic'
                ),
                'images' => array(
                    'type' => 'image',
                    'title' => __('Images', 'pi_framework'),
                    'description' => __('Upload carousel images.', 'pi_framework'),
                    'condition' => array('type', '==', 'basic')
                ),
                'navigation' => array(
                    'type' => 'checkbox',
                    'title' => __('Show navigation', 'pi_framework'),
                    'description' => __('Check this to show navigation.', 'pi_framework'),
                    'default' => '1'
                ),
                'auto_scroll' => array(
                    'type' => 'checkbox',
                    'title' => __('Auto Scroll', 'pi_framework'),
                    'description' => __('Set carousel to auto scroll.', 'pi_framework'),
                    'default' => '0'
                ),
                'timeout' => array(
                    'type' => 'number',
                    'title' => __('Scroll Timeout', 'pi_framework'),
                    'description' => __('Enter scrolling timeout.', 'pi_framework'),
                    'default' => '3000',
                    'options' => array(
                        'step' => 10
                    )
                ),
                'target' => array(
                    'type' => 'checkbox',
                    'title' => __('New window', 'pi_framework'),
                    'description' => __('Open url in new window.', 'pi_framework'),
                    'default' => '0',
                    'condition' => array('type', '==', 'link')
                ),
                'image_link' => array(
                    'type' => 'group',
                    'title' => 'Images',
                    'max' => '',
                    'options' => array(
                        'image' => array(
                            'type' => 'image',
                            'title' => __('Image', 'pi_framework'),
                            'description' => __('Upload carousel image.', 'pi_framework'),
                            'condition' => array('type', '==', 'link')
                        ),
                        'url' => array(
                            'type' => 'text',
                            'title' => __('URL', 'pi_framework'),
                            'description' => __('Enter image URL.', 'pi_framework'),
                            'condition' => array('type', '==', 'link')
                        ),
                    )
                )
            );
        }

    }

}
?>

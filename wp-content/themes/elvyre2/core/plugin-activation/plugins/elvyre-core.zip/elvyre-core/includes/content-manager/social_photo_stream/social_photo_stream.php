<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Social_Photo_Stream")) {

    class CMA_Shortcodes_Social_Photo_Stream extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Social Photo Stream', 'pi_framework');
            $settings['description'] = __('Images from social network profiles.', 'pi_framework');
            $settings['shortcode'] = 'cma_social_photo_stream';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-cma-social-photo-stream', plugin_dir_url(__FILE__) . 'js/social_photo_stream.js', array('jquery', 'social_stream'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'network' => 'dribbble',
                'username' => 'pixel_industry',
                'limit' => '10'
                            ), $atts, 'cma_social_photo_stream'));

            $html = "<div class='widget social-feed' data-network='{$network}' data-username='{$username}' data-limit='{$limit}'></div>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'network' => array(
                    'type' => 'select',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select social network.', 'pi_framework'),
                    'options' => array(
                        'deviantart' => 'DeviantArt',
                        'dribbble' => 'Dribbble',
                        'flickr' => 'Flickr',
                        'instagram' => 'Instagram',
                        'newsfeed' => 'Newsfeed (RSS)',
                        'picasa' => 'Picasa',
                        'pinterest' => 'Pinterest',
                        'youtube' => 'Youtube',
                    ),
                    'default' => 'deviantart'
                ),
                'username' => array(
                    'type' => 'text',
                    'title' => __('Username', 'pi_framework'),
                    'description' => __('Social network username.', 'pi_framework')
                ),
                'limit' => array(
                    'type' => 'number',
                    'title' => __('Limit', 'pi_framework'),
                    'description' => __('Number of images to fetch.', 'pi_framework'),
                    'default' => '10',
                    'options' => array(
                        'min' => 1
                    )
                )
            );
        }

    }

}
?>

(jQuery)(function($) {
    //  Responsive layout, resizing the items
    $('.client-carousel').each(function() {
        var auto = $(this).data('play') == '1';
        var timeoutDuration = $(this).data('timeout');

        $(this).carouFredSel({
            responsive: true,
            width: '100%',
            auto: {
                play: auto,
                timeoutDuration: timeoutDuration
            },
            scroll: 1,
            swipe: {
                onMouse: true,
                onTouch: true
            },
            prev: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav-container").find(".c_prev");
                }
            },
            next: {
                button: function() {
                    return $(this).parent().siblings(".carousel-nav-container").find(".c_next");
                }
            },
            items: {
                width: 170,
                height: '100%',
                visible: {
                    min: 1,
                    max: 6
                }
            }
        });
    });
});
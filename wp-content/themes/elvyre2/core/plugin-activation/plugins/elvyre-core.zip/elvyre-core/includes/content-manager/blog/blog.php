<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Blog")) {

    class CMA_Shortcodes_Blog extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Blog', 'pi_framework');
            $settings['description'] = __('Latest news from your Blog/News section.', 'pi_framework');
            $settings['shortcode'] = 'cma_blog';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            global $is_retina;

            $html_content = '';
            $date_html = '';
            $author_html = '';
            $comments_html = '';

            extract(shortcode_atts(array(
                'type' => 'classic',
                'number' => '3',
                'id' => '',
                'date' => '1',
                'author' => '1',
                'comments' => '1',
                'categories' => '0'
                            ), $atts, 'cma_blog'));

            if (!empty($id)) {
                $args = array(
                    'orderby' => 'post_date',
                    'order' => 'DESC',
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'include' => $id,
                    'cat' => $categories
                );
                $recent_posts = get_posts($args);
            } else {
                $args = array(
                    'numberposts' => $number,
                    'orderby' => 'post_date',
                    'order' => 'DESC',
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'cat' => $categories
                );

                $recent_posts = wp_get_recent_posts($args, 'OBJECT');
            }

            foreach ($recent_posts as $post) {
                $image_class = '';

                // post url
                $post_permalink = get_permalink($post->ID);

                // post thumbnail
                $thumbnail = get_post_thumbnail_id($post->ID);
                $image_url = wp_get_attachment_image_src($thumbnail, 'full');

                $params = ($type == 'classic') ? array("width" => 270, "height" => 212) : array("width" => 70, "height" => 70);
                if ($is_retina) {
                    $params = ($type == 'classic') ? array("width" => 540, "height" => 424) : array("width" => 140, "height" => 140);
                }
                $featured_image = bfi_thumb($image_url[0], $params);

                if ($featured_image) {
                    $post_image_html = "<a href='{$post_permalink}'>
                                    <img src='{$featured_image}' alt='{$post->post_title}' />
                                </a>";
                } else {
                    $post_image_html = '';
                    $image_class = 'no-image';
                }

                //post meta
                $date_format = get_option('date_format');
                $post_date = get_the_time($date_format, $post);

                // post author
                $post_author_name = get_the_author_meta('display_name', $post->post_author);
                $post_author_url = get_author_posts_url($post->post_author);

                // filter the number of comments
                $comments_number = get_comments_number($post->ID);
                if ($comments_number > 1)
                    $output = str_replace('%', number_format_i18n($comments_number), __('% Comments', 'pi_framework'));
                elseif ($comments_number == 0)
                    $output = __('No Comments', 'pi_framework');
                else // must be one
                    $output = __('1 Comment', 'pi_framework');

                $comments_num = apply_filters('comments_number', $output, $comments_number);

                if ($type == 'classic') {
                    if ($date == '1')
                        $date_html = "<li class='icon-clock'>
                                <span>{$post_date}</span>
                            </li>";

                    if ($author == '1')
                        $author_html = "<li class='icon-user'>
                                    <a href='{$post_author_url}'>{$post_author_name}</a>
                                </li>";

                    if ($comments == '1')
                        $comments_html = "<li class='icon-comments'>
                                    <a href='{$post_permalink}'>{$comments_num}</a>
                                </li>";

                    $html_content .= "<li class='post {$image_class}'>
                                <div class='post-media-container'>
                                    {$post_image_html}

                                    <div class='post-media-hover'>
                                        <a href='{$post_permalink}' class='mask'></a>
                                    </div>
                                </div>

                                <a href='{$post_permalink}'>
                                    <h5>{$post->post_title}</h5>
                                </a>

                                <ul class='post-meta'>
                                    {$date_html}
                                    {$author_html}
                                    {$comments_html}
                                </ul>
                            </li>";
                }else {
                    if ($date == '1')
                        $date_html = "<li class='icon-clock'>
                                <span>{$post_date}</span>
                            </li>";

                    if ($comments == '1')
                        $comments_html = "<li class='icon-comments'>
                                    <a href='{$post_permalink}'>{$comments_num}</a>
                                </li>";

                    $html_content .= "<li class='{$image_class}'>";

                    if ($featured_image) {
                        $html_content .= "<div class='post-media'>
                                        {$post_image_html}
                                    </div>";
                    }

                    $html_content .= "<div class='widget-post-info'>
                                        <a href='{$post_permalink}'>
                                            <h6>{$post->post_title}</h6>
                                        </a>

                                        <ul class='meta'>
                                            {$date_html}
                                            {$comments_html}
                                        </ul>
                                    </div>
                                </li>";
                }
            }

            if ($type == 'classic') {
                $html = "<ul class='latest-posts'>{$html_content}</ul>";
            } else {
                $html = "<ul class='pi_recent_posts'>{$html_content}</ul>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select blog type.', 'pi_framework'),
                    'options' => array(
                        'classic' => __('Classic with large images', 'pi_framework'),
                        'simple' => __('Simple (widget style)', 'pi_framework')
                    ),
                    'default' => 'classic'
                ),
                'number' => array(
                    'type' => 'number',
                    'title' => __('Number', 'pi_framework'),
                    'description' => __('Number of blog posts to fetch.', 'pi_framework'),
                    'options' => array(
                        'min' => '1'
                    ),
                    'default' => '1'
                ),
                'id' => array(
                    'type' => 'text',
                    'title' => __('ID\'s', 'pi_framework'),
                    'description' => __('ID\'s of blog posts (comma separated).', 'pi_framework'),
                    'placeholder' => '1,2,3'
                ),
                'categories' => array(
                    'type' => 'text',
                    'title' => __('Categories', 'pi_framework'),
                    'description' => __('ID\'s of categories (comma separated).', 'pi_framework'),
                    'placeholder' => '1,2,3'
                ),
                'date' => array(
                    'type' => 'checkbox',
                    'title' => __('Show date', 'pi_framework'),
                    'description' => __('Check to show date of the post.', 'pi_framework'),
                    'default' => '1'
                ),
                'author' => array(
                    'type' => 'checkbox',
                    'title' => __('Show author', 'pi_framework'),
                    'description' => __('Check to show author of the post.', 'pi_framework'),
                    'default' => '1'
                ),
                'comments' => array(
                    'type' => 'checkbox',
                    'title' => __('Show comments', 'pi_framework'),
                    'description' => __('Check to show number of comments of the post.', 'pi_framework'),
                    'default' => '1'
                ),
            );
        }

    }

}
?>

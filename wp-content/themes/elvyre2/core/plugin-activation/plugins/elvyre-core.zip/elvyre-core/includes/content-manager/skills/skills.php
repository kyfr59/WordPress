<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Skills")) {

    class CMA_Shortcodes_Skills extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Skills', 'pi_framework');
            $settings['description'] = __('Showcase your skills.', 'pi_framework');
            $settings['shortcode'] = 'cma_skills';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-skills', plugin_dir_url(__FILE__) . 'js/skills.js', array('jquery', 'cma-waypoints', 'easy_pie_chart'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            $html_titles = '';
            $html_content = '';
            $html = '';
            $i = 1;

            extract(shortcode_atts(array(
                'type' => 'linear',
                'size' => 'big',
                'skills' => ''
                            ), $atts, 'cma_skills'));

            if ($size == 'big') {
                $chart_size = '110';
            } else {
                $chart_size = '70';
            }

            if ($type == 'circular') {
                $html = "<ul class='skills-circular {$size} load-skills' data-size='{$chart_size}'>";
                foreach ($skills as $index => $skill) {

                    $html .= "<li class='chart easy-pie-chart' data-percent='{$skill['percentage']}'>
                            <div class='percent-container'>
                                <span class='percent'>{$skill['percentage']}%</span>
                            </div>

                            <span class='info'>{$skill['title']}</span>
                        </li>";
                }
                $html .= "</ul>";
            } else {
                $html = "<article class='skills-bar'><ul class='skills'>";
                foreach ($skills as $index => $skill) {

                    $html .= "<li>
                            <span class='percentage-{$skill['percentage']}'></span>
                            <em>{$skill['title']} {$skill['percentage']}%</em>
                        </li>";
                }
                $html .= "</ul></article>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select skills type.', 'pi_framework'),
                    'options' => array(
                        'linear' => __('Linear', 'pi_framework'),
                        'circular' => __('Circular', 'pi_framework')
                    ),
                    'default' => 'linear'
                ),
                'size' => array(
                    'type' => 'radio',
                    'title' => __('Size', 'pi_framework'),
                    'description' => __('Select skills size.', 'pi_framework'),
                    'options' => array(
                        'big' => __('Big', 'pi_framework'),
                        'small' => __('Small', 'pi_framework')
                    ),
                    'default' => 'big'
                ),
                'skills' => array(
                    'type' => 'group',
                    'title' => __('Skills', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'title' => array(
                            'type' => 'text',
                            'title' => __('Title', 'pi_framework'),
                            'description' => __('Skill title.', 'pi_framework')
                        ),
                        'percentage' => array(
                            'type' => 'number',
                            'title' => __('Percentage', 'pi_framework'),
                            'description' => __('Set skill percentage (1-100%).', 'pi_framework'),
                            'options' => array(
                                'min' => 0,
                                'max' => 100,
                                'step' => 10
                            ),
                            'default' => '50'
                        )
                    )
                )
            );
        }

    }

}
?>

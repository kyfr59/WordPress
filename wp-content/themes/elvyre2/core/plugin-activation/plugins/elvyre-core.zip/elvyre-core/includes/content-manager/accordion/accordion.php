<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Accordion")) {

    class CMA_Shortcodes_Accordion extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Accordion', 'pi_framework');
            $settings['description'] = __('Simple UI component.', 'pi_framework');
            $settings['shortcode'] = 'cma_accordion';
            $settings['nested'] = array('cma_accordion_item');

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-accordion', plugin_dir_url(__FILE__) . 'js/accordion.js', array('jquery'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            $html = '';
            $i = 1;

            extract(shortcode_atts(array(
                'type' => 'blue',
                'items' => '',
                'active' => '1'
                            ), $atts, 'cma_accordion'));

            $html .= "<article class='accordion {$type}'>";

            foreach ($items as $index => $item) {

                $item_content = do_shortcode($item['content']);
                $item_content = wpautop($item_content);

                if ($active == $i) {
                    $active_item = 'active';
                } else {
                    $active_item = '';
                }

                $html .= "<div class='title {$active_item}'><a title='{$item['title']}' href='#tab-{$index}{$i} '>{$item['title']}</a></div>";
                $html .= "<div class='content'>{$item_content}</div>";

                $i++;
            }

            $html .= '</article>';

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select accordion type.', 'pi_framework'),
                    'options' => array(
                        'style-1' => __('Blue', 'pi_framework'),
                        'style-2' => __('Clean', 'pi_framework')
                    ),
                    'default' => 'style-1'
                ),
                'active' => array(
                    'type' => 'number',
                    'title' => __('Active item', 'pi_framework'),
                    'description' => __('Enter index of item that you want to be active e.g 2.', 'pi_framework'),
                    'default' => '1'
                ),
                'items' => array(
                    'type' => 'group',
                    'title' => __('Items', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'title' => array(
                            'type' => 'text',
                            'title' => __('Title', 'pi_framework'),
                            'description' => __('Item title.', 'pi_framework')
                        ),
                        'content' => array(
                            'type' => 'textarea',
                            'title' => __('Content', 'pi_framework'),
                            'description' => __('Add item content.', 'pi_framework')
                        )
                    )
                )
            );
        }

    }

}
?>

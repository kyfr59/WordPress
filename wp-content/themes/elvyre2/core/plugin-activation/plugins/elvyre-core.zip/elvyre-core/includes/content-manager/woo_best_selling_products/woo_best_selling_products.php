<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Woo_Best_Selling_Products")) {

    class CMA_Shortcodes_Woo_Best_Selling_Products extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('WooCommerce Best Selling Products', 'pi_framework');
            $settings['description'] = __('List of best selling products.', 'pi_framework');
            $settings['shortcode'] = 'cma_woo_best_selling_products';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'per_page' => '',
                'columns' => '4'
                            ), $atts, 'cma_woo_best_selling_products'));

            $shortcode = "[best_selling_products per_page='{$per_page}' columns='{$columns}']";
            $html = do_shortcode($shortcode);

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'per_page' => array(
                    'type' => 'number',
                    'title' => __('Per Page', 'pi_framework'),
                    'description' => __('Number of products to fetch.', 'pi_framework'),
                    'options' => array(
                        'min' => '1'
                    ),
                    'default' => '12'
                ),
                'columns' => array(
                    'type' => 'select',
                    'title' => __('Columns', 'pi_framework'),
                    'description' => __('Enter index of item that you want to be active e.g 2.', 'pi_framework'),
                    'default' => '4',
                    'options' => array(
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        '7' => '7'
                    )
                ),
            );
        }

    }

}
?>

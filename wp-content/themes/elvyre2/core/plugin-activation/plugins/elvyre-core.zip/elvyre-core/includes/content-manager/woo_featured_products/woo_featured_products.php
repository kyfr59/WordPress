<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Woo_Featured_Products")) {

    class CMA_Shortcodes_Woo_Featured_Products extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('WooCommerce Featured Products', 'pi_framework');
            $settings['description'] = __('List of Featured products.', 'pi_framework');
            $settings['shortcode'] = 'cma_woo_featured_products';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'per_page' => '12',
                'columns' => '4',
                'orderby' => 'date',
                'order' => 'DESC'
                            ), $atts, 'cma_woo_featured_products'));

            $shortcode = "[featured_products per_page='{$per_page}' columns='{$columns}' orderby='{$orderby}' order='{$order}']";
            $html = do_shortcode($shortcode);

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'per_page' => array(
                    'type' => 'number',
                    'title' => __('Per Page', 'pi_framework'),
                    'description' => __('Number of products to fetch.', 'pi_framework'),
                    'options' => array(
                        'min' => '1'
                    ),
                    'default' => '12'
                ),
                'columns' => array(
                    'type' => 'select',
                    'title' => __('Columns', 'pi_framework'),
                    'description' => __('Enter index of item that you want to be active e.g 2.', 'pi_framework'),
                    'default' => '4',
                    'options' => array(
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        '7' => '7'
                    )
                ),
                'orderby' => array(
                    'type' => 'select',
                    'title' => __('Order by', 'pi_framework'),
                    'description' => __('Select how to order products.', 'pi_framework'),
                    'options' => array(
                        'ID' => __('ID', 'pi_framework'),
                        'title' => __('Title', 'pi_framework'),
                        'name' => __('Name', 'pi_framework'),
                        'date' => __('Date', 'pi_framework'),
                        'rand' => __('Random', 'pi_framework')
                    ),
                    'default' => 'date'
                ),
                'order' => array(
                    'type' => 'select',
                    'title' => __('Order', 'pi_framework'),
                    'description' => __('Ascending or descending order of products.', 'pi_framework'),
                    'options' => array(
                        'ASC' => __('Ascending', 'pi_framework'),
                        'DESC' => __('Descending', 'pi_framework')
                    ),
                    'default' => 'DESC'
                ),
            );
        }

    }

}
?>

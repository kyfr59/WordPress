(jQuery)(function($) {
    //  Responsive layout, resizing the items
    $('.nivoSlider').each(function() {
        var manualAdvance = $(this).data('manual') == '1';
        var pauseTime = $(this).data('pause');
        var navigation = $(this).data('navigation') == '1';
        var pauseOnHover = $(this).data('pause-hover') == '1';

        //NIVO SLIDER
        $('.nivoSlider').nivoSlider({
            pauseTime: pauseTime,
            directionNav: navigation,
            manualAdvance: manualAdvance,
            pauseOnHover: pauseOnHover
        });
    });
});
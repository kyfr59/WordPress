<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Timeline")) {

    class CMA_Shortcodes_Timeline extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Timeline', 'pi_framework');
            $settings['description'] = __('Describe your company history.', 'pi_framework');
            $settings['shortcode'] = 'cma_timeline';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'year' => '2014',
                'title' => 'Writing the future',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tincidunt, sapien at dignissim fermentum, magna magna consectetur risus.'
                            ), $atts, 'cma_timeline'));

            $html = "<section class='history'>
                        <div class='year-holder'>
                            <div class='inner-holder'>
                                <span class='year'>{$year}</span>
                            </div>
                        </div>

                        <h4>{$title}</h4>
                        <p>{$description}</p>
                    </section>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'year' => array(
                    'type' => 'number',
                    'title' => __('Year', 'pi_framework'),
                    'description' => __('Enter year of this event.', 'pi_framework'),
                    'default' => '2014'
                ),
                'title' => array(
                    'type' => 'text',
                    'title' => __('Title', 'pi_framework'),
                    'description' => __('Enter event name of some short title.', 'pi_framework')
                ),
                'description' => array(
                    'type' => 'textarea',
                    'title' => __('Description', 'pi_framework'),
                    'description' => __('Enter event description.', 'pi_framework'),
                    'default' => ''
                ),
            );
        }

    }

}
?>

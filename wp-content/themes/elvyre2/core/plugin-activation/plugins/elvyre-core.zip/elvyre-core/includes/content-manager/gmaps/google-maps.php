<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Google_Maps")) {

    class CMA_Shortcodes_Google_Maps extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Google Maps', 'pi_framework');
            $settings['description'] = __('Creates Google Map with location of your choice.', 'pi_framework');
            $settings['shortcode'] = 'cma_google_maps';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* Google Maps script */
            wp_enqueue_script('cma-scripts-googlemaps-api', 'http://maps.google.com/maps/api/js?sensor=true', array('jquery'), '1.0', TRUE);
            /* jQuery plugin for Google Maps */
            wp_enqueue_script('cma-scripts-googlemaps-plugin', plugin_dir_url(__FILE__) . 'js/jquery.ui.map.full.min.js', array('jquery', 'cma-scripts-googlemaps-api'), '1.0', TRUE);
            /* Script for Google Maps */
            wp_enqueue_script('cma-scripts-googlemaps', plugin_dir_url(__FILE__) . 'js/google-maps.js', array('jquery', 'cma-scripts-googlemaps-api', 'cma-scripts-googlemaps-plugin'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'latitude' => "40.74843",
                'longitude' => '-73.985655',
                'zoom' => '13',
                'ui' => '1',
                'scroll' => '1'
                            ), (array) $atts, 'cma_google_maps'));

            $html = "<div class='map-canvas' data-long='{$longitude}' data-lat='{$latitude}' data-zoom='{$zoom}' data-default-ui='{$ui}' data-scroll-wheel='{$scroll}'></div>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'latitude' => array(
                    'type' => 'text',
                    'title' => __('Latitude', 'pi_framework'),
                    'description' => __('Location Latitude for map.', 'pi_framework'),
                    'placeholder' => '46.305746'
                ),
                'longitude' => array(
                    'type' => 'text',
                    'title' => __('Longitude', 'pi_framework'),
                    'description' => __('Location Longitude for map.', 'pi_framework'),
                    'placeholder' => '16.336607'
                ),
                'zoom' => array(
                    'type' => 'number',
                    'title' => __('Zoom', 'pi_framework'),
                    'description' => __('Zoom parameter.', 'pi_framework'),
                    'default' => '13'
                ),
                'ui' => array(
                    'type' => 'checkbox',
                    'title' => __('User Interface', 'pi_framework'),
                    'description' => __('Enable or disable interface for zooming/moving.', 'pi_framework'),
                    'default' => '1'
                ),
                'scroll' => array(
                    'type' => 'checkbox',
                    'title' => __('Zoom scrolling', 'pi_framework'),
                    'description' => __('Zoom when scrolling over map.', 'pi_framework'),
                    'default' => '0'
                ),
            );
        }

    }

}
?>

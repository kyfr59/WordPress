<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Development")) {

    class CMA_Shortcodes_Development extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Development Process', 'pi_framework');
            $settings['description'] = __('You can describe how you develop your product.', 'pi_framework');
            $settings['shortcode'] = 'cma_development';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $development_image_html = '';

            extract(shortcode_atts(array(
                'image' => '',
                'title' => 'Development process',
                'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean est eros, viverra at dolor nec, laoreet rhoncus felis. Maecenas hendrerit posuere luctus. ',
                'link' => ''
                            ), $atts, 'cma_development'));

            // get image if available
            if (!empty($image)) {
                // array of images
                $image = explode(',', $image);

                //get first image
                $image_url = wp_get_attachment_image_src($image[0], 'full');

                // crop image
                $params = array('width' => 100, 'height' => 100);
                if ($is_retina) {
                    $params = array('width' => 200, 'height' => 200);
                }
                $development_image = bfi_thumb($image_url[0], $params);
                $development_image_html = "<div class='img-container'><img src='{$development_image}' alt='{$title}'></div>";
            }

            if (!empty($link)) {
                $link = esc_url($link);                 

                $html = "<section class='process-box'>
                            <a href='{$link}'>
                                {$development_image_html}

                                <h5>{$title}</h5>
                                <p>{$text}</p>
                            </a>
                        </section>";
            } else {
                $html = "<section class='process-box'>
                        {$development_image_html}

                        <h5>{$title}</h5>
                        <p>{$text}</p>
                    </section>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'image' => array(
                    'type' => 'image',
                    'title' => __('Image', 'pi_framework'),
                    'description' => __('Image for Development process box.', 'pi_framework')
                ),
                'title' => array(
                    'type' => 'text',
                    'title' => __('Title', 'pi_framework'),
                    'description' => __('Please enter title.', 'pi_framework')
                ),
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Please enter description.', 'pi_framework')
                ),
                'link' => array(
                    'type' => 'text',
                    'title' => __('Link', 'pi_framework'),
                    'description' => __('Enter url and box will act as link.', 'pi_framework')
                ),
            );
        }

    }

}
?>

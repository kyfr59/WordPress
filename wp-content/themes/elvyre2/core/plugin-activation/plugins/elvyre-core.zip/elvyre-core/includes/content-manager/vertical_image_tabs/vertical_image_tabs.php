<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Vertical_Image_Tabs")) {

    class CMA_Shortcodes_Vertical_Image_Tabs extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Vertical Image Tabs', 'pi_framework');
            $settings['description'] = __('Vertical image tabs with icons.', 'pi_framework');
            $settings['shortcode'] = 'cma_vertical_image_tabs';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-vertical-image-tabs', plugin_dir_url(__FILE__) . 'js/vertical_image_tabs.js', array('jquery'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $html_titles = '';
            $html_content = '';
            $html = '';
            $i = 1;

            extract(shortcode_atts(array(
                'tabs' => '',
                'active' => '1'
                            ), $atts, 'cma_vertical_image_tabs'));

            foreach ($tabs as $index => $tab) {

                if ((int) $active == $i) {
                    $active_tab = 'active';
                } else {
                    $active_tab = '';
                }

                $tab_icon = !empty($tab['icon']) ? "<div class='icon " . $tab['icon'] . "'></div>" : '';

                // array of images
                $image = explode(',', $tab['image']);

                //get first image
                $image_url = wp_get_attachment_image_src($image[0], 'full');

                // crop image
                $params = array('width' => 570, 'height' => 404);
                if ($is_retina) {
                    $params = array('width' => 1140, 'height' => 808);
                }
                $tabs_image = bfi_thumb($image_url[0], $params);

                $html_titles .= "<li class='{$active_tab}'>"
                        . "<a title='{$tab['title']}' href='#tab-{$index}{$i} '>"
                        . "{$tab_icon}"
                        . "<h5>{$tab['title']}</h5>"
                        . "<p>{$tab['subtitle']}</p>"
                        . "</a></li>";
                $html_content .= "<div class='tab-content {$active_tab}' id='tab-{$index}{$i}'><img src='{$tabs_image}' alt='{$tab['title']}'/></div>";
                $i++;
            }

            $html .= "<ul class='tabs services-tabs vertical'>{$html_titles}</ul>";
            $html .= "<section class='tab-content-wrap services-tab-content-wrap vertical'>{$html_content}</section>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'tabs' => array(
                    'type' => 'group',
                    'title' => __('Tabs', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'title' => array(
                            'type' => 'text',
                            'title' => __('Title', 'pi_framework'),
                            'description' => __('Tab title.', 'pi_framework')
                        ),
                        'subtitle' => array(
                            'type' => 'textarea',
                            'title' => __('Subtitle', 'pi_framework'),
                            'description' => __('Add tab subtitle.', 'pi_framework')
                        ),
                        'icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Add tab icon.', 'pi_framework'),
                            'options' => pi_icons_font_names()
                        ),
                        'image' => array(
                            'type' => 'image',
                            'title' => __('Image', 'pi_framework'),
                            'description' => __('Upload tab image.', 'pi_framework')
                        ),
                    )
                ),
                'active' => array(
                    'type' => 'number',
                    'title' => __('Active tab', 'pi_framework'),
                    'description' => __('Enter index of tab that you want to be active.', 'pi_framework'),
                    'default' => '1',
                    'options' => array(
                        'min' => 1
                    )
                )
            );
        }

    }

}
?>

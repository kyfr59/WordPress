(jQuery)(function($) {
    $('.skills-bar').waypoint(function() {
        $('.skills li span').addClass('expand');
    },
            {offset: '70%'}
    );

    // Easy Pie Chart plugin - skills    

    $('.load-skills').waypoint(function() {
        var chartSize = $(this).data('size');
        
        $('.easy-pie-chart').easyPieChart({
            animate: 1000,
            scaleColor: false,
            lineWidth: 3,
            lineCap: 'square',
            size: chartSize,
            trackColor: '#e5e5e5',
            barColor: '#727c89'
        });
    },
            {offset: '60%'}
    );

});
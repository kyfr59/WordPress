<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Team_Member")) {

    class CMA_Shortcodes_Team_Member extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Team Member', 'pi_framework');
            $settings['description'] = __('Your company team member (single member).', 'pi_framework');
            $settings['shortcode'] = 'cma_team_member';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $html_members = '';
            $social_html = '';

            extract(shortcode_atts(array(
                'name' => '',
                'position' => '',
                'text' => '',
                'image' => '',
                'url' => '',
                'social' => '',
                            ), $atts, 'cma_team_member'));

            // team member image
            $image = explode(',', $image);

            //get first image
            $image_url = wp_get_attachment_image_src($image[0], 'full');

            // crop the image
            $params = array('width' => 270, 'height' => 310);
            if ($is_retina) {
                $params = array('width' => 540, 'height' => 620);
            }
            $member_image = bfi_thumb($image_url[0], $params);
            $member_image = "<img src='{$member_image}' alt='{$name}'/>";

            // text cut if it's too long
            $text = _substr($text, 150, 3);

            // team member page
            if (!empty($url)) {
                $url = esc_url($url);

                $hover_link = "<a href='{$url}' class='mask'></a>";
                $image_link = "<a href='{$url}'>
                                    {$member_image}
                                </a>";
                $name_link = "<a href='{$url}'>
                                <h6>{$name}</h6>
                            </a>";
            } else {
                $hover_link = "";
                $image_link = $member_image;
                $name_link = "<h6>{$name}</h6>";
            }

            if (!empty($social) && is_array($social)) {
                // social network icons
                $social_html = "<ul class='team-social-links'>";
                foreach ($social as $network) {
                    $social_url = $network['url'];
                    $social_url = esc_url($social_url);                    

                    $social_html .= "<li>
                                    <a href='{$social_url}' class='{$network['icon']}'></a>
                                </li>";
                }
                $social_html .= "</ul>";
            }

            $html = "<section class='team'>
                    <div class='team-img-container'>
                        {$image_link}

                        <div class='team-img-hover'>
                            {$hover_link}
                        </div>
                    </div>

                    {$name_link}
                    <span class='position'>{$position}</span>

                    <p>{$text}</p>

                    {$social_html}
                </section>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'name' => array(
                    'type' => 'text',
                    'title' => __('Name', 'pi_framework'),
                    'description' => __('Team member name.', 'pi_framework')
                ),
                'position' => array(
                    'type' => 'text',
                    'title' => __('Job position', 'pi_framework'),
                    'description' => __('Enter job position.', 'pi_framework')
                ),
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Write something about employee.', 'pi_framework')
                ),
                'image' => array(
                    'type' => 'image',
                    'title' => __('Image', 'pi_framework'),
                    'description' => __('Please upload team member image', 'pi_framework')
                ),
                'url' => array(
                    'type' => 'text',
                    'title' => __('Page URL', 'pi_framework'),
                    'description' => __('Link to Team member personal page (leave empty to disable link).', 'pi_framework')
                ),
                'social' => array(
                    'type' => 'group',
                    'title' => __('Team members', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Team member social network.', 'pi_framework'),
                            "options" => pi_get_pixons_names()
                        ),
                        'url' => array(
                            'type' => 'text',
                            'title' => __('URL', 'pi_framework'),
                            'description' => __('Social network URL.', 'pi_framework'),
                            'default' => 'http://'
                        )
                    )
                )
            );
        }

    }

}
?>

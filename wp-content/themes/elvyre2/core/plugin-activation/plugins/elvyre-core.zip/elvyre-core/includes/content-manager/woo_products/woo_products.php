<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Woo_Products")) {

    class CMA_Shortcodes_Woo_Products extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('WooCommerce Products [ID/SKU]', 'pi_framework');
            $settings['description'] = __('List of selected products by ID/SKU.', 'pi_framework');
            $settings['shortcode'] = 'cma_woo_products';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            $html = '';

            extract(shortcode_atts(array(
                'fetch_by' => 'ids',
                'ids' => '',
                'skus' => '',
                'columns' => '4',
                'orderby' => 'date',
                'order' => 'DESC'
                            ), $atts, 'cma_woo_products'));

            if ($fetch_by == 'ids' && !empty($ids)) {
                $shortcode = "[products ids='{$ids}' columns='{$columns}' orderby='{$orderby}' order='{$order}']";
                $html = do_shortcode($shortcode);
            } else if ($fetch_by == 'skus' && !empty($skus)) {
                $shortcode = "[products skus='{$skus}' columns='{$columns}' orderby='{$orderby}' order='{$order}']";
                $html = do_shortcode($shortcode);
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'fetch_by' => array(
                    'type' => 'radio',
                    'title' => __('Fetch by', 'pi_framework'),
                    'description' => __('Select do you want to fetch products by ID or by SKU.', 'pi_framework'),
                    'options' => array(
                        'ids' => 'ID',
                        'skus' => 'SKU'
                    ),
                    'default' => 'ids'
                ),
                'ids' => array(
                    'type' => 'text',
                    'title' => __('IDs', 'pi_framework'),
                    'description' => __('Enter product IDs (comma separated).', 'pi_framework'),
                    'default' => '',
                    'condition' => array('fetch_by', '==', 'ids'),
                ),
                'skus' => array(
                    'type' => 'text',
                    'title' => __('SKUs', 'pi_framework'),
                    'description' => __('Enter product SKUs (comma separated).', 'pi_framework'),
                    'condition' => array('fetch_by', '==', 'skus'),
                    'default' => ''
                ),
                'columns' => array(
                    'type' => 'select',
                    'title' => __('Columns', 'pi_framework'),
                    'description' => __('Enter index of item that you want to be active e.g 2.', 'pi_framework'),
                    'default' => '4',
                    'options' => array(
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        '7' => '7'
                    )
                ),
                'orderby' => array(
                    'type' => 'select',
                    'title' => __('Order by', 'pi_framework'),
                    'description' => __('Select how to order products.', 'pi_framework'),
                    'options' => array(
                        'ID' => __('ID', 'pi_framework'),
                        'title' => __('Title', 'pi_framework'),
                        'name' => __('Name', 'pi_framework'),
                        'date' => __('Date', 'pi_framework'),
                        'rand' => __('Random', 'pi_framework')
                    ),
                    'default' => 'date'
                ),
                'order' => array(
                    'type' => 'select',
                    'title' => __('Order', 'pi_framework'),
                    'description' => __('Ascending or descending order of products.', 'pi_framework'),
                    'options' => array(
                        'ASC' => __('Ascending', 'pi_framework'),
                        'DESC' => __('Descending', 'pi_framework')
                    ),
                    'default' => 'DESC'
                ),
            );
        }

    }

}
?>

<?php

/* * **********************************************
 * 
 * Post MetaBoxes
 * 
 * Used to generate metaboxes for certain posts.
 * 
 * ************************************************ */


/* --------------------------------- 
 * MetaBox for Custom Post Types
  --------------------------------- */

function pi_register_meta_boxes() {

    // Get avaliable pages
    $all_avaliable_pages = get_pages('sort_column=post_parent,menu_order');
    $pages[''] = 'Select a page';
    foreach ($all_avaliable_pages as $page) {
        $pages[$page->ID] = $page->post_title;
    }

    $meta_boxes = array();

    // Define a meta box for Pages

    $prefix = 'pg_';

    $meta_boxes[] = array(
        'title' => __('Page Options', 'pi_framework'),
        'pages' => array('page'),
        'fields' => array(
            array(
                'name' => __('Sidebar', 'pi_framework'),
                'desc' => __('Page can have left or right sidebar.', 'pi_framework'),
                'id' => "{$prefix}sidebar",
                'type' => 'image_select',
                'std' => 'fullwidth',
                'options' => array(
                    'fullwidth' => ELV_PLUGIN_URL . '/img/page/fullwidth.png',
                    'left' => ELV_PLUGIN_URL . '/img/page/left.png',
                    'right' => ELV_PLUGIN_URL . '/img/page/right.png'
                )
            ),
            // Portfolio type
            array(
                'name' => __('Portfolio Style', 'pi_framework'),
                'id' => "{$prefix}portfolio_style",
                'type' => 'select',
                'options' => array(
                    '2-col' => __('2 Column', 'pi_framework'),
                    '3-col' => __('3 Column', 'pi_framework'),
                    '4-col' => __('4 Column', 'pi_framework'),
                    'full' => __('Full width', 'pi_framework')
                ),
                'std' => 'Select portfolio style',
                'desc' => __('Select portfolio style.', 'pi_framework'),
            ),
            array(
                'name' => __('Portfolio Taxonomy IDs', 'pi_framework'),
                'id' => "{$prefix}portfolio_taxonomies",
                'desc' => __('Show only specific taxonomies (enter comma separated IDs).', 'pi_framework'),
                'type' => 'text',
                'std' => '',
            ),
            array(
                'name' => __('Hide page title', 'pi_framework'),
                'id' => "{$prefix}hide_title",
                'desc' => __('Check this to hide page title.', 'pi_framework'),
                'type' => 'checkbox',
                'std' => '0'
            ),
            array(
                'name' => __('Nice title', 'pi_framework'),
                'id' => "{$prefix}page_description",
                'desc' => __('Nice title will replace page title.', 'pi_framework'),
                'type' => 'text',
                'std' => '',
            ),
            array(
                'name' => __('Title style', 'pi_framework'),
                'desc' => __('Select desired title style.', 'pi_framework'),
                'id' => "{$prefix}title_style",
                'type' => 'select',
                'std' => 'large',
                'options' => array(
                    '1' => 'Large (Title + Breadcrumbs + Image)',
                    '2' => 'Medium (Title + Breadcrumbs)',
                    '3' => 'Small (Breadcrumbs)'
                )
            ),
            array(
                'name' => __('Background color', 'pi_framework'),
                'desc' => __('Set title background color.', 'pi_framework'),
                'id' => "{$prefix}title_color",
                'type' => 'color'
            ),
            // Image Upload
            array(
                'name' => __('Background image', 'pi_framework'),
                'desc' => __('Set background image. Two images allowed, first will show on all devices, second on Retina devices.', 'pi_framework'),
                'id' => "{$prefix}title_image",
                'type' => 'image_advanced',
                'max_file_uploads' => 2
            ),
            // Image Upload
            array(
                'name' => __('Additional image', 'pi_framework'),
                'desc' => __('Image that will appear on the right side of the title.', 'pi_framework'),
                'id' => "{$prefix}additional_title_image",
                'type' => 'image_advanced',
                'max_file_uploads' => 1
            ),
            array(
                'name' => __('Parallax', 'pi_framework'),
                'id' => "{$prefix}parallax",
                'desc' => __('Check this to enable parallax effect. Note that you need to upload large enough image to support this feature.', 'pi_framework'),
                'type' => 'checkbox',
                'std' => '1'
            ),
        )
    );

    // Define a meta box for Blog

    $prefix = 'pt_';
    $meta_boxes[] = array(
        'title' => __('Post Format Options', 'pi_framework'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'type' => 'heading',
                'name' => __('No options for this post format.', 'pi_framework'),
                'id' => 'post_format_options', // Not used but needed for plugin
            ),
            // Video URL
            array(
                'name' => __('Video Embed Code', 'pi_framework'),
                'id' => $prefix . 'video_url',
                'desc' => __('Please enter embed code (iframe).', 'pi_framework'),
                'type' => 'textarea',
                'std' => '',
            ),
            // Quote text
            array(
                'name' => __('Quote text', 'pi_framework'),
                'id' => $prefix . 'quote_text',
                'desc' => __('Please enter here quote text.', 'pi_framework'),
                'type' => 'textarea',
                'std' => '',
            ),
            array(
                'name' => __('Author', 'pi_framework'),
                'id' => $prefix . 'quote_author',
                'desc' => __('Please enter quote author.', 'pi_framework'),
                'type' => 'text',
                'std' => '',
            ),
            // Audio files
            array(
                'name' => __('Audio files', 'pi_framework'),
                'id' => $prefix . 'audio_files',
                'desc' => __('Please enter link to audio file(s), one per line. Check <a href="http://www.jplayer.org/latest/developer-guide/#reference-html5-audio-format">here</a> which audio formats are supported by popular browsers.', 'pi_framework'),
                'type' => 'textarea',
                'std' => '',
            ),
            // Gallery images
            array(
                'name' => __('Gallery images', 'pi_framework'),
                'id' => $prefix . 'gallery_images',
                'desc' => __('Upload images for gallery. <strong>Minimum size:</strong> 620px x 308px', 'pi_framework'),
                'type' => 'image_advanced'
            )
        )
    );

    // Define a meta box for Portfolio

    $prefix = 'pf_';
    $meta_boxes[] = array(
        'title' => __('Portfolio Item Customization', 'pi_framework'),
        'context' => 'side',
        'priority' => 'low',
        'pages' => array('pi_portfolio'),
        'fields' => array(
            // Show Button
            array(
                'name' => __('Show/Hide Button', 'pi_framework'),
                'id' => "{$prefix}show_hide_button",
                'desc' => __('Opposite of the global value from Theme options.', 'pi_framework'),
                'type' => 'checkbox',
                'std' => '0'
            ),
            array(
                'name' => __('Custom Button Text', 'pi_framework'),
                'id' => $prefix . 'button_text',
                'desc' => __('Enter the button text. This value will override default value from Theme options.', 'pi_framework'),
                'type' => 'text',
                'std' => '',
            ),
            array(
                'name' => __('Custom Button URL', 'pi_framework'),
                'id' => $prefix . 'button_url',
                'desc' => __('Enter the button URL. This value will override default value from Theme options.', 'pi_framework'),
                'type' => 'text',
                'std' => '',
            )
        )
    );

    $meta_boxes[] = array(
        'title' => __('Item Options', 'pi_framework'),
        'pages' => array('pi_portfolio'),
        'fields' => array(
            // Image Upload
            array(
                'name' => __('Portfolio Image', 'pi_framework'),
                'desc' => __('Upload portfolio image(s). Minimum image size: 540px x 363px.', 'pi_framework'),
                'id' => "{$prefix}image",
                'type' => 'image_advanced'
            )
        )
    );

    if (class_exists('RW_Meta_Box')) {
        foreach ($meta_boxes as $meta_box) {
            new RW_Meta_Box($meta_box);
        }
    }
}

add_filter('rwmb_meta_boxes', 'pi_register_meta_boxes');
?>

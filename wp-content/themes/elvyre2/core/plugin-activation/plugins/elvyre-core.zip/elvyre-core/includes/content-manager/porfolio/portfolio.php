<?php
// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Portfolio")) {

    class CMA_Shortcodes_Portfolio extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Portfolio', 'pi_framework');
            $settings['description'] = __('Section where you can list your recent work.', 'pi_framework');
            $settings['shortcode'] = 'cma_potfolio';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-portfolio', plugin_dir_url(__FILE__) . 'js/portfolio.js', array('jquery', 'caroufredsel', 'prettyphoto'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $include_posts = "";
            $exclude_posts = "";
            $id_counter = 1;
            $randomID = rand(1, 99);
            $size = 3;
            $html_content = '';

            extract(shortcode_atts(array(
                'include' => '',
                'exclude' => '',
                'auto_scroll' => '0',
                'timeout' => '2500',
                'show_zoom' => '1',
                'show_link' => '1',
                'image_lightbox' => '0',
                'lightbox_current' => '0',
                'number' => '8',
                'ssba' => '1'
                            ), $atts, 'cma_potfolio'));

            if ($include != "") {
                $include_posts = explode(',', $include);
            } else if ($exclude != "") {
                $exclude_posts = explode(',', $exclude);
            }

            $args = array('post_type' => 'pi_portfolio', 'post__in' => $include_posts, 'post__not_in' => $exclude_posts, 'orderby' => 'post__in', 'posts_per_page' => $number);

            // The Query
            $the_query = new WP_Query($args);

            while ($the_query->have_posts()) : $the_query->the_post();

                $post_permalink = get_permalink();
                $post_title = get_the_title();
                $images = get_post_custom_values('pf_image', get_the_ID());
                $image = wp_get_attachment_image_src($images[0], 'large');
                $first_item_id = $images[0];
                $params = array('width' => 584, 'height' => 462);
                if ($is_retina) {
                    $params = array('width' => 1168, 'height' => 924);
                }
                $cropped_image = bfi_thumb($image[0], $params);

                ob_start();
                ?>

                <li class="isotope-item">

                    <figure class="portfolio-img-container">
                        <div class="portfolio-img">
                            <?php if ($image_lightbox == '1' && $show_zoom == '0' && $show_link == '0') { ?>
                                <a href="<?php echo $image[0]; ?>" data-gal="prettyPhoto[pp_gallery<?php echo $lightbox_current == '1' ? "_" . $id_counter : '' ?>]">

                                <?php } else { ?>
                                    <a href="<?php echo $post_permalink; ?>">
                                    <?php } ?>
                                    <img src="<?php echo $cropped_image ?>" 
                                         alt="<?php echo $post_title ?>" 
                                         width="584"                                                 
                                         />
                                </a>
                                <?php
                                if ($show_zoom == '1' || $show_link == '1') {
                                    ?>
                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <?php if ($show_zoom == '1'): ?>
                                                <li class="portfolio-zoom <?php if ($show_link == '0') echo "single"; ?>">
                                                    <a href="<?php echo $image[0]; ?>" 
                                                       data-gal="prettyPhoto[pp_gallery<?php echo $lightbox_current == '1' ? "_" . $id_counter : '' ?>]" class="icon-expand-2"></a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if ($show_link == '1'): ?>
                                                <li class="portfolio-single <?php if ($show_zoom == '0') echo "single"; ?>">
                                                    <a href="<?php echo $post_permalink; ?>" class="icon-redo"></a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->
                                    <?php
                                }

                                if ($lightbox_current == '1') {
                                    foreach ($images as $id => $val) {
                                        $image = wp_get_attachment_image_src($val, 'large');

                                        // prevent first item duplicate
                                        if ($val == $first_item_id)
                                            continue;
                                        ?>
                                        <a class="hidden-portfolio-image" href="<?php echo $image[0] ?>" data-gal="prettyPhoto[pp_gallery_<?php echo $id_counter ?>]">
                                            <img src="<?php echo $image[0] ?>" 
                                                 alt="<?php echo $post_title ?>"                                                     
                                                 />
                                        </a>
                                        <?php
                                    }
                                }
                                ?>
                        </div>

                        <figcaption>
                            <a class="title" href="<?php echo $post_permalink; ?>"><?php echo $post_title ?></a>
                            <?php
                            if (shortcode_exists('ssba') && $ssba == '1') {
                                $shortcode = "[ssba url='{$post_permalink}']";
                                ?>
                                <div class="portfolio-item-like"><?php echo do_shortcode($shortcode) ?></div>
                            <?php } ?>
                        </figcaption>
                    </figure>
                </li>
                <?php
                $html_content .= ob_get_clean();
                $id_counter++;

            endwhile;

            $navigation = "<div class='clearfix'></div>
                        <ul class='carousel-nav'>
                            <li>
                                <a class='c_prev' href='#'></a> 
                            </li>
                            <li>
                                <a class='c_next' href='#'></a>
                            </li>
                        </ul>";

            $html = "<article><ul class='carousel-li pi-portfolio-carousel' data-play='{$auto_scroll}' data-timeout='{$timeout}'>{$html_content}</ul>{$navigation}</article>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'number' => array(
                    'type' => 'number',
                    'title' => __('Number', 'pi_framework'),
                    'description' => __('Number of portfolio items to get.', 'pi_framework'),
                    'default' => '8',
                    'options' => array(
                        'min' => 1
                    )
                ),
                'auto_scroll' => array(
                    'type' => 'checkbox',
                    'title' => __('Auto Scroll', 'pi_framework'),
                    'description' => __('Set portfolio carousel to auto scroll.', 'pi_framework'),
                    'default' => '0'
                ),
                'timeout' => array(
                    'type' => 'number',
                    'title' => __('Scroll Timeout', 'pi_framework'),
                    'description' => __('Enter scrolling timeout.', 'pi_framework'),
                    'default' => '3000',
                    'options' => array(
                        'step' => 10
                    )
                ),
                'show_zoom' => array(
                    'type' => 'checkbox',
                    'title' => __('Zoom Icon', 'pi_framework'),
                    'description' => __('Show zoom icon.', 'pi_framework'),
                    'default' => '1'
                ),
                'show_link' => array(
                    'type' => 'checkbox',
                    'title' => __('Link Icon', 'pi_framework'),
                    'description' => __('Show link icon.', 'pi_framework'),
                    'default' => '1'
                ),
                'image_lightbox' => array(
                    'type' => 'checkbox',
                    'title' => __('Image Lightbox', 'pi_framework'),
                    'description' => __('Use image as link for lightbox. Link and zoom icons must be hidden.', 'pi_framework'),
                    'default' => '0'
                ),
                'lightbox_current' => array(
                    'type' => 'checkbox',
                    'title' => __('Images Filter', 'pi_framework'),
                    'description' => __('Lightbox will open images from current project.', 'pi_framework'),
                    'default' => '0'
                ),
                'include' => array(
                    'type' => 'text',
                    'title' => __('Include', 'pi_framework'),
                    'description' => __('Enter posts that will be included (only those).', 'pi_framework'),
                    'placeholder' => 'e.g. 1,2,3'
                ),
                'exclude' => array(
                    'type' => 'text',
                    'title' => __('Exclude', 'pi_framework'),
                    'description' => __('Enter posts that will be excluded.', 'pi_framework'),
                    'placeholder' => 'e.g. 1,2,3'
                ),
                'ssba' => array(
                    'type' => 'checkbox',
                    'title' => __('Simple Share Buttons', 'pi_framework'),
                    'description' => __('Show share buttons on this element (Simple Share Buttons Adder must be installed and activated).', 'pi_framework'),
                    'default' => '1'
                ),
            );
        }

    }

}
?>

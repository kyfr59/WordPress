<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Notifications")) {

    class CMA_Shortcodes_Notifications extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Notification', 'pi_framework');
            $settings['description'] = __('Simple UI component.', 'pi_framework');
            $settings['shortcode'] = 'cma_notifications';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-notifications', plugin_dir_url(__FILE__) . 'js/notifications.js', array('jquery'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'type' => 'horizontal',
                'text' => '',
                'close' => '0'
                            ), $atts, 'cma_notifications'));

            if ($close == '1') {
                $html = "<section class='information-boxes {$type}'><span class='close'></span><p>{$text}</p></section>";
            } else {
                $html = "<section class='{$type}'><p>{$text}</p></section>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'select',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select notification type.', 'pi_framework'),
                    'options' => array(
                        'infobox' => __('Information', 'pi_framework'),
                        'error-box' => __('Error', 'pi_framework'),
                        'success-box' => __('Success', 'pi_framework'),
                        'warning-box' => __('Warning', 'pi_framework')
                    ),
                    'default' => 'infobox'
                ),
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Notification text.', 'pi_framework')
                ),
                'close' => array(
                    'type' => 'checkbox',
                    'title' => __('Allow closing', 'pi_framework'),
                    'description' => __('Allow closing notification.', 'pi_framework'),
                    'default' => '0'
                )
            );
        }

    }

}
?>

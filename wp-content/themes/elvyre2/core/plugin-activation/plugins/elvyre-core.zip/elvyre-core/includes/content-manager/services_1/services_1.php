<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Services_1")) {

    class CMA_Shortcodes_Services_1 extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Services - Carousel/List', 'pi_framework');
            $settings['description'] = __('Two styles of services: Carousel & List.', 'pi_framework');
            $settings['shortcode'] = 'cma_services_1';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-services-1', plugin_dir_url(__FILE__) . 'js/services_1.js', array('jquery', 'caroufredsel'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'type' => 'carousel',
                'auto_scroll' => '0',
                'timeout' => '3000',
                'services' => '',
                'link_area' => '0'
                            ), $atts, 'cma_services'));


            // two services styles
            if ($type == 'carousel') {
                $html = "<ul class='carousel-li services-carousel' data-play='{$auto_scroll}' data-timeout='{$timeout}'>";

                foreach ($services as $index => $service) {

                    // get service link
                    if (!empty($service['custom_link'])) {
                        $link = esc_url($service['custom_link']);
                    } else if (!empty($service['link']) && $service['link'] != '-1') {
                        $link = get_permalink($service['link']);
                    } else {
                        $link = false;
                    }

                    // set default icon
                    $icon = empty($service['icon']) ? 'icon-leaf' : $service['icon'];

                    $html .= "<li class='service-box-1'>";

                    if ($link_area == '1' && !empty($link))
                        $html .= "<a href='{$link}'>";

                    $html .= "<div class='icon {$icon}'></div>";

                    if (!empty($link) && $link_area == '0') {
                        $html .= "<a href='{$link}'>
                                <h5>{$service['text']}</h5>
                            </a>";
                    } else {
                        $html .= "<h5>{$service['text']}</h5>";
                    }

                    $html .= "<p>{$service['description']}</p>";

                    if ($link_area == '1' && !empty($link))
                        $html .= "</a>";

                    $html .= "</li>";
                }

                $html .= "</ul>";

                // navigation
                $html .= "<div class='clearfix'></div>
                        <ul class='carousel-nav'>
                            <li>
                                <a class='c_prev' href='#'></a> 
                            </li>
                            <li>
                                <a class='c_next' href='#'></a>
                            </li>
                        </ul>";
            } else {
                $html = "<ul class='services-overview'>";

                foreach ($services as $index => $service) {

                    // get service link
                    if (!empty($service['custom_link'])) {
                        $link = esc_url($service['custom_link']);
                    } else if (!empty($service['link']) && $service['link'] != '-1') {
                        $link = get_permalink($service['link']);
                    } else {
                        $link = false;
                    }

                    // set default icon
                    $icon = empty($service['icon']) ? 'icon-leaf' : $service['icon'];

                    $html .= "<li class='{$icon}'>";

                    if ($link_area == '1' && !empty($link))
                        $html .= "<a href='{$link}'>";

                    if (!empty($link) && $link_area == '0') {
                        $html .= "<a href='{$link}'>
                                <h5>{$service['text']}</h5>
                            </a>";
                    } else {
                        $html .= "<h5>{$service['text']}</h5>";
                    }

                    $html .= "<p>{$service['description']}</p>";
                    
                    if ($link_area == '1' && !empty($link))
                        $html .= "</a>";
                    
                    $html .= "</li>";
                }

                $html .= "</ul>";
            }


            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select services type.', 'pi_framework'),
                    'options' => array(
                        'carousel' => __('Carousel', 'pi_framework'),
                        'list' => __('List', 'pi_framework'),
                    ),
                    'default' => 'carousel'
                ),
                'auto_scroll' => array(
                    'type' => 'checkbox',
                    'title' => __('Auto Scroll', 'pi_framework'),
                    'description' => __('Set services to auto scroll.', 'pi_framework'),
                    'default' => '0',
                    'condition' => array('type', '==', 'carousel')
                ),
                'timeout' => array(
                    'type' => 'number',
                    'title' => __('Scroll Timeout', 'pi_framework'),
                    'description' => __('Enter scrolling timeout.', 'pi_framework'),
                    'default' => '3000',
                    'options' => array(
                        'step' => 10
                    ),
                    'condition' => array('type', '==', 'carousel')
                ),
                'link_area' => array(
                    'type' => 'checkbox',
                    'title' => __('Link Area', 'pi_framework'),
                    'description' => __('Enable if you want to use whole service area as link.', 'pi_framework'),
                    'default' => '0'
                ),
                'services' => array(
                    'type' => 'group',
                    'title' => __('Services', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'text' => array(
                            'type' => 'text',
                            'title' => __('Title', 'pi_framework'),
                            'description' => __('Service title.', 'pi_framework')
                        ),
                        'description' => array(
                            'type' => 'textarea',
                            'title' => __('Description', 'pi_framework'),
                            'description' => __('Service description.', 'pi_framework')
                        ),
                        'icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Add service icon.', 'pi_framework'),
                            'options' => pi_icons_font_names()
                        ),
                        'link' => array(
                            'type' => 'select',
                            'title' => __('Link', 'pi_framework'),
                            'description' => __('Link to page from this service.', 'pi_framework'),
                            'data' => 'pages',
                            'default' => 'carousel'
                        ),
                        'custom_link' => array(
                            'type' => 'text',
                            'title' => __('Custom URL', 'pi_framework'),
                            'description' => __('Enter custom URL for this service.', 'pi_framework')
                        ),
                    )
                )
            );
        }

    }

}
?>

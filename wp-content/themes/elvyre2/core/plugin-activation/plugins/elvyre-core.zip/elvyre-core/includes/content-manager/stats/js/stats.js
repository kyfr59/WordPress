(jQuery)(function($) {
    $('.numbers-counter').waypoint(function() {
        // NUMBERS COUNTER START
        $('.numbers').data('countToOptions', {
            formatter: function(value, options) {
                return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            }
        });
        // start timer
        $('.timer').each(count);

        function count(options) {
            var $this = $(this);
            options = $.extend({}, options || {}, $this.data('countToOptions') || {});
            $this.countTo(options);
        } // NUMBERS COUNTER END
    },
            {offset: '70%'}
    );

});
<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Dropcaps")) {

    class CMA_Shortcodes_Dropcaps extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Dropcaps', 'pi_framework');
            $settings['description'] = __('Stylize first letter of paragraph.', 'pi_framework');
            $settings['shortcode'] = 'cma_dropcaps';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'type' => 'circle',
                'color' => 'colored',
                'text' => 'Dropcap text goes here.'
                            ), $atts, 'cma_dropcaps'));

            $firstLetter = substr($text, 0, 1);
            $slicedString = substr($text, 1);

            $html = "<p><span class='dropcap {$type} {$color}'>{$firstLetter}</span>{$slicedString}</p>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select dropcap type.', 'pi_framework'),
                    'options' => array(
                        'circle' => __('Circle', 'pi_framework'),
                        'square' => __('Square', 'pi_framework')
                    ),
                    'default' => 'circle'
                ),
                'color' => array(
                    'type' => 'radio',
                    'title' => __('Color', 'pi_framework'),
                    'description' => __('Select dropcap color.', 'pi_framework'),
                    'options' => array(
                        'colored' => __('Theme\'s Color', 'pi_framework'),
                        'black' => __('Black', 'pi_framework')
                    ),
                    'default' => 'colored'
                ),
                'text' => array(
                    'type' => 'textarea',
                    'title' => __('Text', 'pi_framework'),
                    'description' => __('Dropcap text.', 'pi_framework')
                )
            );
        }

    }

}
?>

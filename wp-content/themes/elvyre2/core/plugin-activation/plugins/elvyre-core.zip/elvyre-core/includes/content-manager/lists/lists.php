<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Lists")) {

    class CMA_Shortcodes_Lists extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Lists', 'pi_framework');
            $settings['description'] = __('Basic HTML list element.', 'pi_framework');
            $settings['shortcode'] = 'cma_lists';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'icons_style' => 'one',
                'type' => 'theme',
                'size' => 'normal',
                'icon' => 'icon-checkmark-circle-list',
                'items' => ''
                            ), $atts, 'cma_lists'));

            if ($icons_style == 'one')
                $html = "<ul class='icons-list {$type} {$icon}-list {$size}'>";
            else
                $html = "<ul class='icons-list {$type} {$size} list-custom'>";

            foreach ($items as $index => $item) {
                if ($icons_style == 'different')
                    $item_icon = !empty($item['item_icon']) ? "<i class='" . $item['item_icon'] . "'></i>" : "<i class='icon-checkmark-circle'></i>";
                else
                    $item_icon = '';

                $html .= "<li><p>{$item_icon}{$item['text']}</p></li>";
            }

            $html .= "</ul>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'icons_style' => array(
                    'type' => 'radio',
                    'title' => __('Icons style', 'pi_framework'),
                    'description' => __('List items will have same icons or different.', 'pi_framework'),
                    'options' => array(
                        'one' => __('Same icon (for all items)', 'pi_framework'),
                        'different' => __('Different icons', 'pi_framework')
                    ),
                    'default' => 'one'
                ),
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select list type.', 'pi_framework'),
                    'options' => array(
                        'colored' => __('Theme color', 'pi_framework'),
                        'black' => __('Black', 'pi_framework')
                    ),
                    'default' => 'colored'
                ),
                'size' => array(
                    'type' => 'radio',
                    'title' => __('Size', 'pi_framework'),
                    'description' => __('Select list size.', 'pi_framework'),
                    'options' => array(
                        'normal' => __('Normal', 'pi_framework'),
                        'big' => __('Large', 'pi_framework')
                    ),
                    'default' => 'normal'
                ),
                'icon' => array(
                    'type' => 'icon_picker',
                    'title' => __('Icon', 'pi_framework'),
                    'description' => __('Add icon to all list items.', 'pi_framework'),
                    'condition' => array('icons_style', '==', 'one'),
                    'options' => pi_icons_font_names()
                ),
                'items' => array(
                    'type' => 'group',
                    'title' => __('Items', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'text' => array(
                            'type' => 'text',
                            'title' => __('Text', 'pi_framework'),
                            'description' => __('List item text.', 'pi_framework')
                        ),
                        'item_icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Add icon to list item.', 'pi_framework'),
                            'condition' => array('icons_style', '==', 'different'),
                            'options' => pi_icons_font_names()
                        ),
                    )
                )
            );
        }

    }

}
?>

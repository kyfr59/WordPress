<?php

/* -----------------------------------------------------------------------------------

  Plugin Name: Elvyre Core plugin
  Plugin URI: http://www.pixel-industry.com
  Description: A core plugin for Elvyre Wordpress theme.
  Version: 1.4
  Author: Pixel Industry
  Author URI: http://www.pixel-industry.com

  ----------------------------------------------------------------------------------- */

// declare constants
if (!defined('ELV_PLUGIN_DIR'))
    define('ELV_PLUGIN_DIR', untrailingslashit(dirname(__FILE__)));

if (!defined('ELV_PLUGIN_URL'))
    define('ELV_PLUGIN_URL', untrailingslashit(plugins_url('', __FILE__)));

// verify that user is on device with retina display
if (isset($_COOKIE["elv_device_pixel_ratio"])) {
    $is_retina = ( $_COOKIE["elv_device_pixel_ratio"] >= 2 );
}

// Enqueue scripts
function pi_elv_enqueue_styles() {
    wp_register_style('basic', ELV_PLUGIN_URL . '/css/basic.css', array(), '1.0', 'screen');
    wp_register_style('font-awesome', ELV_PLUGIN_URL . '/includes/font-awesome/css/font-awesome.min.css', array(), '1.0', 'screen');
    wp_register_style('pixons', ELV_PLUGIN_URL . '/includes/pixons/style.css', array(), '1.0', 'screen');
    wp_register_style('nivoslider', ELV_PLUGIN_URL . '/css/nivo-slider.css', array(), '1.0', 'screen');
    wp_register_style('style', ELV_PLUGIN_URL . '/css/style.css', array(), '1.0', 'screen');
    wp_register_style('elv_color_style', ELV_PLUGIN_URL . "/css/color.css", array(), '1.0', 'screen');

    wp_enqueue_style('basic');
    wp_enqueue_style('font-awesome');
    wp_enqueue_style('pixons');
    wp_enqueue_style('nivoslider');
    wp_enqueue_style('style');
    wp_enqueue_style('elv_color_style');
}

add_action('wp_enqueue_scripts', 'pi_elv_enqueue_styles');

// Enqueue scripts
function pi_elv_enqueue_scripts() {

    /* jQuery Easing - plugin for animating */
    wp_register_script('easing', ELV_PLUGIN_URL . '/js/jquery.easing.1.2.js', 'jquery', '1.0', TRUE);
    /* PrettyPhoto lightbox plugin */
    wp_register_script('prettyphoto', ELV_PLUGIN_URL . '/js/jquery.prettyPhoto.js', array('jquery', 'easing'), '1.0', TRUE);
    /* Nivo slider - Image slider */
    wp_register_script('nivoslider', ELV_PLUGIN_URL . '/js/jquery.nivo.slider.js', 'jquery', '1.0', TRUE);
    /* CarouFredSel carousel plugin */
    wp_register_script('caroufredsel', ELV_PLUGIN_URL . '/js/jquery.carouFredSel-6.0.0-packed.js', 'jquery', '1.0', TRUE);
    /* Isotope jQuery plugin for portfolio filtering */
    wp_register_script('isotope', ELV_PLUGIN_URL . '/js/jquery.isotope.min.js', array('jquery'), '1.0', TRUE);
    /* Social stream plugin */
    wp_register_script('social_stream', ELV_PLUGIN_URL . '/js/socialstream.jquery.js', array('jquery'), '1.0', TRUE);
    /* jQuery CountTo plugin */
    wp_register_script('count-to', ELV_PLUGIN_URL . '/js/jquery.countTo.js', array('jquery'), '1.0', TRUE);
    /* jQuery EasyPiechart plugin */
    wp_register_script('easy_pie_chart', ELV_PLUGIN_URL . '/js/easypiechart.js', array('jquery'), '1.0', TRUE);
    /* Portfolio custom options */
    wp_register_script('pi_portfolio', ELV_PLUGIN_URL . '/js/portfolio.js', array('jquery', 'prettyphoto', 'isotope'), '1.0', TRUE);

    // load javascript scripts
    wp_enqueue_script('holder');

    if (is_page_template('portfolio-template.php')) {
        wp_enqueue_script('pi_portfolio');
        wp_enqueue_script('prettyphoto');
    }

    if (is_singular('pi_portfolio') || is_tax('portfolio-category')) {
        wp_enqueue_script('caroufredsel');
        wp_enqueue_script('nivoslider');
        wp_enqueue_script('pi_portfolio');
    }
}

add_action('wp_enqueue_scripts', 'pi_elv_enqueue_scripts', 11);

function pi_elv_include_scripts() {
    // including all scripts required for theme proper work
    // Load script for registering all post types.
    require_once( ELV_PLUGIN_DIR . '/includes/post-types.php' );

    // Include the meta box definitions
    include_once ( ELV_PLUGIN_DIR . '/includes/post-metabox.php' );

    // Load file with Icon Font functions
    require_once( ELV_PLUGIN_DIR . "/includes/libs/icon-fonts.php" );

    // Include the Aqua Resizer script
    include_once ( ELV_PLUGIN_DIR . '/includes/libs/BFI_Thumb.php' );

    // Include helper functions
    require_once ( ELV_PLUGIN_DIR . '/includes/libs/helper.php' );
}

add_action('after_setup_theme', 'pi_elv_include_scripts', 12);

/* -------------------------------------------------------------------- 
 * Plugin localization
  -------------------------------------------------------------------- */

function pi_plugin_translation() {
    // Make theme available for translation
    //load_plugin_textdomain('pi_framework', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/');

    $domain = 'pi_framework';
    // The "plugin_locale" filter is also used in load_plugin_textdomain()
    $locale = apply_filters('plugin_locale', get_locale(), $domain);

    load_textdomain($domain, WP_LANG_DIR . '/elvyre-core/' . $domain . '-' . $locale . '.mo');
    load_plugin_textdomain($domain, FALSE, dirname(plugin_basename(__FILE__)) . '/languages/');
}

// Add actions
add_action('init', 'pi_plugin_translation');

/* -------------------------------------------------------------------- 
 * Load scripts to Wordpress admin
  -------------------------------------------------------------------- */
if (!function_exists('pi_load_custom_wp_admin_scripts')) {

    function pi_load_custom_wp_admin_scripts($hook) {
        if ($hook != 'edit.php')
            return;
        /* Image placeholder jQuery plugin */
        wp_register_script('holder', ELV_PLUGIN_URL . '/js/holder.js', array('jquery'), '1.0', TRUE);
        wp_enqueue_script('holder');
    }

}
add_action('admin_enqueue_scripts', 'pi_load_custom_wp_admin_scripts');

/* ------------------------------------------------------------------
 * Shortcodes filter function. Clears unnecessary <p> and <br/> tags.
  ------------------------------------------------------------------- */
if (!function_exists('shortcode_empty_paragraph_fix')) {

    function pi_shortcode_empty_paragraph_fix($content) {

        // array of custom shortcodes requiring the fix 
        $theme_shortcodes = array(
            'grid_1',
            'grid_2',
            'grid_3',
            'grid_4',
            'grid_5',
            'grid_6',
            'grid_7',
            'grid_8',
            'grid_9',
            'grid_10',
            'grid_11',
            'grid_12',
            'divider',
            'dropcap',
            'list',
            'button',
            'blockquote',
            'highlight',
            'info_boxes',
            'tabs',
            'tab',
            'accordion',
            'accordion_item',
            'title',
            'note',
            'cta',
            'blog',
            'social_feed',
            'services',
            'portfolio_carousel',
            'team',
            'gmaps',
            'testimonials',
            'testimonial',
            'testimonials_alt',
            'testimonial_alt',
            'image_slider',
            'image_carousel',
            'pi_skills',
            'pi_skill',
            'sliding_text',
            'slide_text',
            'contact_info'
        );

        // join all shortcode into string
        $block = join("|", $theme_shortcodes);

        // opening tag
        $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/", "[$2$3]", $content);

        // closing tag
        $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/", "[/$2]", $rep);

        return $rep;
    }

}
add_filter('the_content', 'pi_shortcode_empty_paragraph_fix');

function pi_add_cma_content_directory($dirs) {
    $dirs[] = ELV_PLUGIN_DIR . '/includes/content-manager/';

    return $dirs;
}

add_filter('cma_shortcodes_directory', 'pi_add_cma_content_directory');
?>
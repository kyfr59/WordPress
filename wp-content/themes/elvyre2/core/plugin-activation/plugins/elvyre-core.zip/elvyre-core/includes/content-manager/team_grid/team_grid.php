<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Team_Grid")) {

    class CMA_Shortcodes_Team_Grid extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Team Members Grid', 'pi_framework');
            $settings['description'] = __('Team members grid section.', 'pi_framework');
            $settings['shortcode'] = 'cma_team_grid';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function shortcode_html($atts = array(), $content = null) {
            global $is_retina;

            $html_members = '';

            extract(shortcode_atts(array(
                'team' => '',
                'readmore' => __('Read more', 'pi_framework')
                            ), $atts, 'cma_team_grid'));

            foreach ($team as $member) {
                $page = '';

                // team member image
                $image = explode(',', $member['image']);

                //get first image
                $image_url = wp_get_attachment_image_src($image[0], 'full');

                // crop the image
                $params = array('width' => 284, 'height' => 225);
                if ($is_retina) {
                    $params = array('width' => 568, 'height' => 450);
                }
                $member_image = bfi_thumb($image_url[0], $params);
                $member_image = "<img src='{$member_image}' alt='{$member['name']}'/>";

                if ($member['url'] != "-1") {
                    $link = !empty($member['url']) ? get_permalink($member['url']) : '';
                    $page = "<a href='{$link}' class='btn-medium empty white'>{$readmore}</a>";
                }

                $html_members .= "<li class='team-member'>
                                    {$member_image}

                                    <div class='team-member-hover'>
                                        <div class='mask'></div>

                                        <div class='team-member-info'>
                                            <h5>{$member['name']}</h5>
                                            <span class='position'>{$member['position']}</span>
                                            {$page}
                                        </div>
                                    </div>
                                </li>";
            }

            $html = "<ul class='team-alternative'>{$html_members}</ul>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'team' => array(
                    'type' => 'group',
                    'title' => __('Team members', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'name' => array(
                            'type' => 'text',
                            'title' => __('Name', 'pi_framework'),
                            'description' => __('Team member name.', 'pi_framework')
                        ),
                        'position' => array(
                            'type' => 'text',
                            'title' => __('Job position', 'pi_framework'),
                            'description' => __('Enter job position.', 'pi_framework')
                        ),
                        'image' => array(
                            'type' => 'image',
                            'title' => __('Image', 'pi_framework'),
                            'description' => __('Please upload team member image', 'pi_framework')
                        ),
                        'url' => array(
                            'type' => 'select',
                            'title' => __('Page URL', 'pi_framework'),
                            'description' => __('Link to Team member personal page (leave empty to hide button).', 'pi_framework'),
                            'default' => '',
                            'data' => 'pages'
                        )
                    )
                ),
                'readmore' => array(
                    'type' => 'text',
                    'title' => __('Read More', 'pi_framework'),
                    'description' => __('Read More button text.', 'pi_framework'),
                    'default' => 'Read More'
                ),
            );
        }

    }

}
?>

<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Stats")) {

    class CMA_Shortcodes_Stats extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Stats', 'pi_framework');
            $settings['description'] = __('Animated statistics.', 'pi_framework');
            $settings['shortcode'] = 'cma_stats';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-stats', plugin_dir_url(__FILE__) . 'js/stats.js', array('jquery', 'count-to', 'cma-waypoints'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            extract(shortcode_atts(array(
                'stats' => ''
                            ), $atts, 'cma_stats'));

            $html = "<ul class='numbers-counter'>";

            foreach ($stats as $item) {
                $html .= "<li>
                        <span class='timer number' data-to='{$item['number']}' data-speed='2000'>{$item['number']}</span>
                        <p>{$item['text']}</p>
                    </li>";
            }

            $html .= "</ul>";

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'stats' => array(
                    'type' => 'group',
                    'title' => __('Stats', 'pi_framework'),
                    'max' => '',
                    'options' => array(
                        'text' => array(
                            'type' => 'text',
                            'title' => __('Text', 'pi_framework'),
                            'description' => __('Enter item title/text.', 'pi_framework')
                        ),
                        'number' => array(
                            'type' => 'number',
                            'title' => __('Number', 'pi_framework'),
                            'description' => __('Enter number/count..', 'pi_framework')
                        ),
                    )
                )
            );
        }

    }

}
?>

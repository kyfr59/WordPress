(jQuery)(function($) {

    /* ================ GOOGLE MAPS ================ */
    $('.map-canvas').each(function() {
        var longitude = $(this).data('long');
        var latitude = $(this).data('lat');
        var zoom = parseInt($(this).data('zoom'));
        var defaultUi = $(this).data('default-ui') == '0';
        var scrollWheel = $(this).data('scroll-wheel') == '1';

        var yourStartLatLng = new google.maps.LatLng(latitude, longitude);
        $(this).gmap({
            center: yourStartLatLng,
            zoom: zoom,
            disableDefaultUI: defaultUi,
            scrollwheel: scrollWheel,
            callback: function() {
                var self = this;
                self.addMarker({
                    position: this.get('map').getCenter()
                });
            }
        });
    });
});


<?php

// Prevent loading file directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists("CMA_Shortcodes_Tabs")) {

    class CMA_Shortcodes_Tabs extends Content_Manager_Shortcodes {

        function shortcode_block_info() {
            $settings['title'] = __('Tabs', 'pi_framework');
            $settings['description'] = __('Simple UI component.', 'pi_framework');
            $settings['shortcode'] = 'cma_tabs';
            $settings['nested'] = false;

            $this->shortcode_settings = $settings;
        }

        function enqueue_scripts() {
            /* script */
            wp_enqueue_script('cma-scripts-tabs', plugin_dir_url(__FILE__) . 'js/tabs.js', array('jquery'), '1.0', TRUE);
        }

        function shortcode_html($atts = array(), $content = null) {

            $html_titles = '';
            $html_content = '';
            $html = '';
            $i = 1;

            extract(shortcode_atts(array(
                'type' => 'horizontal',
                'tabs' => '',
                'active' => '1'
                            ), $atts, 'cma_tabs'));

            $randomID = rand(1, 999);

            foreach ($tabs as $index => $tab) {

                $tab_content = do_shortcode($tab['content']);

                if ((int) $active == $i) {
                    $active_tab = 'active';
                } else {
                    $active_tab = '';
                }

                $tab_icon = !empty($tab['icon']) ? "<i class='" . $tab['icon'] . "'></i>" : '';

                $html_titles .= "<li class='{$active_tab}'><a title='{$tab['title']}' href='#tab-{$randomID}-{$i} '>{$tab_icon}{$tab['title']}</a></li>";

                $tab_content = wpautop($tab_content);
                $html_content .= "<div class='tab-content {$active_tab}' id='tab-{$randomID}-{$i}'>{$tab_content}</div>";

                $i++;
            }

            if ($type == 'vertical') {
                $html .= "<div class='tabs-container'><ul class='tabs vertical' id='tabs-{$randomID}'>{$html_titles}</ul>";
                $html .= "<section class='tab-content-wrap vertical'>{$html_content}</section></div>";
            } else {
                $html .= "<div class='tabs-container'><ul class='tabs' id='tabs-{$randomID}'>{$html_titles}</ul>";
                $html .= "<section class='tab-content-wrap'>{$html_content}</section></div>";
            }

            return $html;
        }

        function shortcode_options_fields() {

            $this->shortcode_options = array(
                'type' => array(
                    'type' => 'radio',
                    'title' => __('Type', 'pi_framework'),
                    'description' => __('Select tab type.', 'pi_framework'),
                    'options' => array(
                        'horizontal' => __('Horizontal', 'pi_framework'),
                        'vertical' => __('Vertical', 'pi_framework')
                    ),
                    'default' => 'horizontal'
                ),
                'active' => array(
                    'type' => 'number',
                    'title' => __('Active tab', 'pi_framework'),
                    'description' => __('Enter index of tab that you want to be active e.g 2.', 'pi_framework'),
                    'default' => '1',
                    'options' => array(
                        'min' => 1
                    )
                ),
                'tabs' => array(
                    'type' => 'group',
                    'title' => 'Tabs',
                    'max' => '',
                    'options' => array(
                        'title' => array(
                            'type' => 'text',
                            'title' => __('Title', 'pi_framework'),
                            'description' => __('Tab title.', 'pi_framework')
                        ),
                        'content' => array(
                            'type' => 'textarea',
                            'title' => __('Content', 'pi_framework'),
                            'description' => __('Add tab content.', 'pi_framework')
                        ),
                        'icon' => array(
                            'type' => 'icon_picker',
                            'title' => __('Icon', 'pi_framework'),
                            'description' => __('Add tab icon.', 'pi_framework'),
                            'options' => pi_icons_font_names()
                        ),
                    )
                )
            );
        }

    }

}
?>

(jQuery)(function($){

    /* ================ ACCORDION ================ */
    
    (function(){
        $('.accordion').on('click', '.title', function(event) {
            event.preventDefault();
            var $this = $(this);
            $this.closest('.accordion').find('.active').next().slideUp('normal');
            $this.closest('.accordion').find('.title').removeClass("active");        
            if($this.next().is(':hidden') === true) {
                $this.next().slideDown('normal');
                $this.addClass("active");
            }
        });
        $('.accordion .content').hide();
        $('.accordion .active').next().slideDown('normal');
    })();
});
<?php
/* -----------------------------------------------------------------------------------

  Plugin Name: Recent posts Widget
  Plugin URI: http://www.pixel-industry.com
  Description: A widget that displays recent posts from blog.
  Version: 1.2
  Author: Pixel Industry
  Author URI: http://www.pixel-industry.com

  ----------------------------------------------------------------------------------- */

// declare constants
if (!defined('WRP_PLUGIN_DIR'))
    define('WRP_PLUGIN_DIR', untrailingslashit(dirname(__FILE__)));

if (!defined('WRP_PLUGIN_URL'))
    define('WRP_PLUGIN_URL', untrailingslashit(plugins_url('', __FILE__)));

// Add function to widgets_init that'll load our widget
add_action('widgets_init', 'rpw_posts_widget_init');

// Register widget
function rpw_posts_widget_init() {
    register_widget('RPW_Posts_Widget');
}

// Enqueue scripts
function rpw_enqueue_styles() {
    /* jQuery tweetscroll plugin */
    wp_register_style('rpw-style', WRP_PLUGIN_URL . '/css/style.css', array(), '1.0', 'screen');
    // load javascript scripts
    wp_enqueue_style('rpw-style');
}

add_action('wp_enqueue_scripts', 'rpw_enqueue_styles');

// Widget class
class RPW_Posts_Widget extends WP_Widget {
    /* ----------------------------------------------------------------------------------- */
    /* 	Widget Setup
      /*----------------------------------------------------------------------------------- */

    function RPW_Posts_Widget() {

        // Widget settings
        $widget_options = array(
            'classname' => 'rpw_posts_widget',
            'description' => __('A widget that displays blog recent posts.', 'rpw_plugin')
        );


        // Create the widget
        $this->WP_Widget('RPW_Posts_Widget_Init', __('Recent Posts Widget', 'rpw_plugin'), $widget_options);
		
		
		// Add actions
		add_action('init', array($this, 'pi_plugin_translation'));
    }

    /* ----------------------------------------------------------------------------------- */
    /* 	Display Widget
      /*----------------------------------------------------------------------------------- */

    function widget($args, $instance) {
        extract($args);

        // Our variables from the widget settings
        $title = apply_filters('widget_title', $instance['title']);
        $limit = $instance['limit'];
        $category = $instance['category'];
        $exclude = $instance['exclude'];

        // Before widget (defined by theme functions file)
        echo $before_widget;

        // Display the widget title if one was input
        if ($title)
            echo $before_title . $title . $after_title;

        echo '<ul class="rpw-footer-blog">';
        if (is_numeric($limit))
            $valid_limit = $limit;
        else
            $valid_limit = "";

        if ($category != "false")
            $valid_category = $category;
        else
            $valid_category = "";

        $exclude_array = explode(',', $exclude);
        $category_args = array('post_type' => 'post', 'posts_per_page' => $valid_limit, 'category_name' => $valid_category, 'post__not_in' => $exclude_array);
        // The Query
        $the_query = new WP_Query($category_args);
        while ($the_query->have_posts()) : $the_query->the_post();

            // Will be used in in future
            /*
              $clean_categories = array();
              $categories = get_the_category();
              foreach ($categories as $one_cat) {
              $clean_categories[$one_cat->cat_ID] = $one_cat->name;
              }
              $categories_string = implode(', ', $clean_categories);
             */

            // set icon for each post format
            $post_format = get_post_format();
            $post_format = $post_format === false ? 'image' : $post_format;

            if ($post_format == 'image') {
                $post_icon = 'edit';
            } else if ($post_format == 'gallery') {
                $post_icon = 'camera';
            } else if ($post_format == 'video') {
                $post_icon = 'play';
            } else if ($post_format == 'audio') {
                $post_icon = 'microphone';
            } else if ($post_format == 'quote') {
                $post_icon = 'quote-left';
            } else if ($post_format == 'link') {
                $post_icon = 'link';
            }
            
            $num_of_comments = $this->rpw_get_number_of_comments(get_the_ID());
            $date_format = get_option('date_format');
            ?>
            <li>
                <div class="meta">
                    <p>
                        <a class="icon-<?php echo $post_icon ?>"></a>
                    </p>
                </div>
                <div class="post">
                    <a href="<?php the_permalink() ?>"><?php echo _substr(get_the_title(), 30, 3) ?></a> 
                    <p class="info"><?php echo strtoupper(get_the_time($date_format)); ?>, <a href="<?php the_permalink() ?>"><?php echo $num_of_comments ?></a></p>

                </div> 
            </li> 

            <?php
        endwhile;

        // Restore original Query & Post Data
        wp_reset_query();
        wp_reset_postdata();

        echo '</ul>';
        // After widget (defined by theme functions file)
        echo $after_widget;
    }

    /* ----------------------------------------------------------------------------------- */
    /* 	Update Widget
      /*----------------------------------------------------------------------------------- */

    function update($new_instance, $old_instance) {
        $instance = $old_instance;

        // Strip tags to remove HTML (important for text inputs)
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['limit'] = strip_tags($new_instance['limit']);
        $instance['category'] = strip_tags($new_instance['category']);
        $instance['exclude'] = strip_tags($new_instance['exclude']);

        // No need to strip tags

        return $instance;
    }

    /* ----------------------------------------------------------------------------------- */
    /* 	Widget Settings (Displays the widget settings controls on the widget panel)
      /*----------------------------------------------------------------------------------- */

    function form($instance) {

        // Set up some default widget settings
        $defaults = array(
            'title' => 'Recent posts',
            'limit' => '2',
            'category' => '',
            'exclude' => '',
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>

        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'rpw_plugin') ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
        </p>

        <!-- Limit: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _e('Number of posts to show:', 'rpw_plugin') ?></label>
            <input type="number" class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" value="<?php echo $instance['limit']; ?>" />
        </p>

        <!-- Category: Select -->
        <p>
            <label for="<?php echo $this->get_field_id('category'); ?>" ><?php _e('Category filter:', 'rpw_plugin') ?></label><br />
            <select id="<?php echo $this->get_field_id('category'); ?>" name="<?php echo $this->get_field_name('category'); ?>">
                <option <?php if ($instance['category'] == "") echo 'selected' ?> value="false">None</option>
                <?php
                $args = array(
                    'orderby' => 'name',
                    'order' => 'ASC'
                );

                $categories = get_categories($args);
                foreach ($categories as $category) {
                    ?>
                    <option <?php if ($instance['category'] == $category->slug) echo 'selected' ?> value="<?php echo $category->slug ?>"><?php echo $category->name ?></option>
                    <?php
                }
                ?>               
            </select>
        </p>

        <!-- Exclude: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id('category'); ?>"><?php _e('Exlude post (comma separated IDs):', 'rpw_plugin') ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('exclude'); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" value="<?php echo $instance['exclude']; ?>" />
        </p>

        <?php
    }

    function rpw_get_number_of_comments($post_id) {
        // filter the number of comments
        $comments_number = get_comments_number($post_id);
        if ($comments_number > 1)
            $output = str_replace('%', number_format_i18n($comments_number), __('% Comments', 'rpw_plugin'));
        elseif ($comments_number == 0)
            $output = __('No Comments', 'rpw_plugin');
        else // must be one
            $output = __('1 Comment', 'rpw_plugin');

        $comments_num = apply_filters('comments_number', $output, $comments_number);
        
        return $comments_num;
    }
	
	/* -------------------------------------------------------------------- 
	 * Plugin localization
	  -------------------------------------------------------------------- */
	function pi_plugin_translation() {
		
		$domain = 'rpw_plugin';
		// The "plugin_locale" filter is also used in load_plugin_textdomain()
		$locale = apply_filters('plugin_locale', get_locale(), $domain);

		load_textdomain($domain, WP_LANG_DIR.'/recent-posts-widget/'.$domain.'-'.$locale.'.mo');
		load_plugin_textdomain($domain, FALSE, dirname(plugin_basename(__FILE__)).'/languages/');
	}


}
?>